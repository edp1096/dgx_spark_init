"""Pipeline lifecycle management and model configuration."""

import gc
import logging
import os
from pathlib import Path

import torch

from ltx_core.loader import LTXV_LORA_COMFY_RENAMING_MAP, LoraPathStrengthAndSDOps
from ltx_core.quantization import QuantizationPolicy
from ltx_pipelines.utils.constants import LTX_2_3_PARAMS

FP8_QUANTIZATION = QuantizationPolicy.fp8_cast()

logger = logging.getLogger("ltx2-ui")

# ---------------------------------------------------------------------------
# Defaults & Constants
# ---------------------------------------------------------------------------
DEFAULTS = LTX_2_3_PARAMS
DEFAULT_MODEL_DIR = os.environ.get("LTX_MODEL_DIR", str(Path(__file__).resolve().parent.parent / "models" / "ltx-2.3"))

OUTPUT_DIR = os.environ.get("LTX_OUTPUT_DIR", "/tmp/ltx2-outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

RESOLUTION_CHOICES = [
    "1024x1536", "1536x1024",
    "1024x1024",
    "768x1024", "1024x768",
    "512x768", "768x512",
    "544x960", "960x544",
]
FRAME_CHOICES = [9, 17, 25, 33, 41, 49, 57, 65, 73, 81, 89, 97, 121, 161, 193]

SAMPLE_PROMPTS = [
    "A woman with long brown hair and light skin smiles at another woman with long blonde hair. The woman with brown hair wears a black jacket and has a small, barely noticeable parsing. The camera angle is a close-up, focused on the woman with brown hair's face. The lighting is warm and the background is softly blurred, suggesting an indoor setting.",
    "A golden retriever puppy runs through a sunlit meadow, tall grass swaying gently in the breeze. The camera follows low to the ground, capturing the puppy's joyful expression as it bounds forward. Warm afternoon light creates a soft golden glow across the scene.",
    "Aerial drone shot of ocean waves crashing against rocky cliffs at sunset. The camera slowly pulls back to reveal the dramatic coastline. Mist rises from the impact of waves, catching orange and pink light from the setting sun.",
    "A steaming cup of coffee sits on a wooden table by a rain-streaked window. Water droplets slowly trace paths down the glass. The camera slowly racks focus from the cup to the blurred city lights outside. Warm interior lighting contrasts with the cool blue tones of the rainy evening.",
    "Time-lapse of a flower blooming in a dark studio. A single white lily unfurls its petals under soft directional lighting. The background is completely black, making the flower appear to glow. The camera is static, capturing every subtle movement of the petals opening.",
]

REQUIRED_MODELS = {
    "ti2vid": ["ltx-2.3-22b-dev-fp8.safetensors", "ltx-2.3-spatial-upscaler-x2-1.0.safetensors",
               "ltx-2.3-22b-distilled-lora-384.safetensors", "gemma-3-12b-it-qat-q4_0-unquantized"],
    "distilled": ["ltx-2.3-22b-distilled-fp8.safetensors", "ltx-2.3-spatial-upscaler-x2-1.0.safetensors",
                  "gemma-3-12b-it-qat-q4_0-unquantized"],
    "iclora": ["ltx-2.3-22b-distilled-fp8.safetensors", "ltx-2.3-spatial-upscaler-x2-1.0.safetensors",
               "gemma-3-12b-it-qat-q4_0-unquantized"],
    "keyframe": ["ltx-2.3-22b-dev-fp8.safetensors", "ltx-2.3-spatial-upscaler-x2-1.0.safetensors",
                 "ltx-2.3-22b-distilled-lora-384.safetensors", "gemma-3-12b-it-qat-q4_0-unquantized"],
    "a2vid": ["ltx-2.3-22b-dev-fp8.safetensors", "ltx-2.3-spatial-upscaler-x2-1.0.safetensors",
              "ltx-2.3-22b-distilled-lora-384.safetensors", "gemma-3-12b-it-qat-q4_0-unquantized"],
    "retake": ["ltx-2.3-22b-dev-fp8.safetensors", "gemma-3-12b-it-qat-q4_0-unquantized"],
}

IC_LORA_MAP = {
    "Union Control": "ltx-2.3-22b-ic-lora-union-control-ref0.5.safetensors",
    "Inpainting": "ltx-2.3-22b-ic-lora-inpainting.safetensors",
    "Motion Track": "ltx-2.3-22b-ic-lora-motion-track-control-ref0.5.safetensors",
    "Detailer": "ltx-2-19b-ic-lora-detailer.safetensors",
    "Pose Control": "ltx-2-19b-ic-lora-pose-control.safetensors",
}


# ---------------------------------------------------------------------------
# Pipeline Manager
# ---------------------------------------------------------------------------
class PipelineManager:
    """Manages pipeline lifecycle — one active pipeline at a time."""

    def __init__(self) -> None:
        self.current_pipeline = None
        self.current_type: str | None = None
        self.model_dir: str = DEFAULT_MODEL_DIR
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._iclora_path: str | None = None

    def _cleanup(self) -> None:
        if self.current_pipeline is not None:
            logger.info("Cleaning up pipeline: %s", self.current_type)
            del self.current_pipeline
            self.current_pipeline = None
            self.current_type = None
            self._iclora_path = None
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                torch.cuda.synchronize()

    def check_models(self, pipeline_type: str) -> list[str]:
        """Return list of missing model files for a pipeline type."""
        required = REQUIRED_MODELS.get(pipeline_type, [])
        missing = []
        for f in required:
            path = Path(self.model_dir) / f
            if not path.exists():
                missing.append(f)
        return missing

    def _model_path(self, filename: str) -> str:
        return str(Path(self.model_dir) / filename)

    def _gemma_root(self) -> str:
        return self._model_path("gemma-3-12b-it-qat-q4_0-unquantized")

    def _distilled_lora(self, strength: float = 0.8) -> list[LoraPathStrengthAndSDOps]:
        return [LoraPathStrengthAndSDOps(
            self._model_path("ltx-2.3-22b-distilled-lora-384.safetensors"),
            strength,
            LTXV_LORA_COMFY_RENAMING_MAP,
        )]

    def get_ti2vid(self, sampler: str = "euler", quantization=None):
        target = "ti2vid_hq" if sampler == "res_2s" else "ti2vid"
        if self.current_type == target:
            return self.current_pipeline
        self._cleanup()
        if sampler == "res_2s":
            from ltx_pipelines.ti2vid_two_stages_hq import TI2VidTwoStagesHQPipeline
            self.current_pipeline = TI2VidTwoStagesHQPipeline(
                checkpoint_path=self._model_path("ltx-2.3-22b-dev-fp8.safetensors"),
                distilled_lora=self._distilled_lora(),
                distilled_lora_strength_stage_1=0.3,
                distilled_lora_strength_stage_2=0.8,
                spatial_upsampler_path=self._model_path("ltx-2.3-spatial-upscaler-x2-1.0.safetensors"),
                gemma_root=self._gemma_root(),
                loras=(),
                device=self.device,
                quantization=FP8_QUANTIZATION,
            )
        else:
            from ltx_pipelines.ti2vid_two_stages import TI2VidTwoStagesPipeline
            self.current_pipeline = TI2VidTwoStagesPipeline(
                checkpoint_path=self._model_path("ltx-2.3-22b-dev-fp8.safetensors"),
                distilled_lora=self._distilled_lora(),
                spatial_upsampler_path=self._model_path("ltx-2.3-spatial-upscaler-x2-1.0.safetensors"),
                gemma_root=self._gemma_root(),
                loras=[],
                device=self.device,
                quantization=FP8_QUANTIZATION,
            )
        self.current_type = target
        return self.current_pipeline

    def get_distilled(self, quantization=None):
        if self.current_type == "distilled":
            return self.current_pipeline
        self._cleanup()
        from ltx_pipelines.distilled import DistilledPipeline
        self.current_pipeline = DistilledPipeline(
            distilled_checkpoint_path=self._model_path("ltx-2.3-22b-distilled-fp8.safetensors"),
            gemma_root=self._gemma_root(),
            spatial_upsampler_path=self._model_path("ltx-2.3-spatial-upscaler-x2-1.0.safetensors"),
            loras=[],
            device=self.device,
            quantization=FP8_QUANTIZATION,
        )
        self.current_type = "distilled"
        return self.current_pipeline

    def get_retake(self, distilled: bool = False, quantization=None):
        target = "retake_distilled" if distilled else "retake"
        if self.current_type == target:
            return self.current_pipeline
        self._cleanup()
        from ltx_pipelines.retake import RetakePipeline
        ckpt = "ltx-2.3-22b-distilled-fp8.safetensors" if distilled else "ltx-2.3-22b-dev-fp8.safetensors"
        self.current_pipeline = RetakePipeline(
            checkpoint_path=self._model_path(ckpt),
            gemma_root=self._gemma_root(),
            loras=[],
            device=self.device,
            quantization=FP8_QUANTIZATION,
        )
        self.current_type = target
        return self.current_pipeline

    def get_keyframe(self, quantization=None):
        if self.current_type == "keyframe":
            return self.current_pipeline
        self._cleanup()
        from ltx_pipelines.keyframe_interpolation import KeyframeInterpolationPipeline
        self.current_pipeline = KeyframeInterpolationPipeline(
            checkpoint_path=self._model_path("ltx-2.3-22b-dev-fp8.safetensors"),
            distilled_lora=self._distilled_lora(),
            spatial_upsampler_path=self._model_path("ltx-2.3-spatial-upscaler-x2-1.0.safetensors"),
            gemma_root=self._gemma_root(),
            loras=[],
            device=self.device,
            quantization=FP8_QUANTIZATION,
        )
        self.current_type = "keyframe"
        return self.current_pipeline

    def get_a2vid(self, quantization=None):
        if self.current_type == "a2vid":
            return self.current_pipeline
        self._cleanup()
        from ltx_pipelines.a2vid_two_stage import A2VidPipelineTwoStage
        self.current_pipeline = A2VidPipelineTwoStage(
            checkpoint_path=self._model_path("ltx-2.3-22b-dev-fp8.safetensors"),
            distilled_lora=self._distilled_lora(),
            spatial_upsampler_path=self._model_path("ltx-2.3-spatial-upscaler-x2-1.0.safetensors"),
            gemma_root=self._gemma_root(),
            loras=[],
            device=self.device,
            quantization=FP8_QUANTIZATION,
        )
        self.current_type = "a2vid"
        return self.current_pipeline

    def get_iclora(self, lora_path: str, lora_strength: float = 1.0, quantization=None):
        # Reuse if same LoRA is already loaded
        if self.current_type == "iclora" and self._iclora_path == lora_path:
            return self.current_pipeline
        self._cleanup()
        from ltx_pipelines.ic_lora import ICLoraPipeline
        loras = [LoraPathStrengthAndSDOps(lora_path, lora_strength, LTXV_LORA_COMFY_RENAMING_MAP)]
        self.current_pipeline = ICLoraPipeline(
            distilled_checkpoint_path=self._model_path("ltx-2.3-22b-distilled-fp8.safetensors"),
            spatial_upsampler_path=self._model_path("ltx-2.3-spatial-upscaler-x2-1.0.safetensors"),
            gemma_root=self._gemma_root(),
            loras=loras,
            device=self.device,
            quantization=FP8_QUANTIZATION,
        )
        self.current_type = "iclora"
        self._iclora_path = lora_path
        return self.current_pipeline


pipeline_mgr = PipelineManager()
