"""Download LTX-2.3 model files from HuggingFace.

Downloads sequentially (ISP QoS limits parallel connections).
Resumes from where it left off if interrupted.

Usage:
    python download_models.py                    # Download all required models
    python download_models.py --only distilled   # Download specific file
    python download_models.py --status            # Check download status
    python download_models.py --list              # List all downloadable files
"""

import argparse
import sys
from pathlib import Path

MODEL_DIR = Path(__file__).resolve().parent.parent / "models" / "ltx-2.3"
REPO_ID = "Lightricks/LTX-2.3"

# (filename, description, required)
DOWNLOADS = [
    ("ltx-2.3-22b-dev.safetensors", "Dev checkpoint (~44GB)", True),
    ("ltx-2.3-22b-distilled.safetensors", "Distilled checkpoint (~44GB)", True),
    ("ltx-2.3-spatial-upscaler-x2-1.0.safetensors", "2x Spatial upscaler (~950MB)", True),
    ("ltx-2.3-22b-distilled-lora-384.safetensors", "Distilled LoRA (~7.1GB)", True),
]

GEMMA_REPO = "google/gemma-3-12b-it-qat-q4_0-unquantized"
GEMMA_DESC = "Gemma text encoder (~12GB, gated repo — HF login required)"


def format_size(size_bytes: int) -> str:
    if size_bytes >= 1024**3:
        return f"{size_bytes / 1024**3:.1f}GB"
    if size_bytes >= 1024**2:
        return f"{size_bytes / 1024**2:.0f}MB"
    return f"{size_bytes / 1024:.0f}KB"


def check_status() -> None:
    print(f"Model directory: {MODEL_DIR}\n")

    print("=== LTX-2.3 Models ===")
    for fname, desc, required in DOWNLOADS:
        path = MODEL_DIR / fname
        tag = "required" if required else "optional"
        if path.exists():
            size = format_size(path.stat().st_size)
            print(f"  [  OK  ] {fname} ({size})")
        else:
            print(f"  [MISSING] {fname} ({tag})")

    print(f"\n=== Gemma Text Encoder ===")
    gemma_path = MODEL_DIR / "gemma-3-12b-it-qat-q4_0-unquantized"
    if gemma_path.exists():
        print(f"  [  OK  ] gemma-3-12b-it-qat-q4_0-unquantized/ (dir)")
    else:
        print(f"  [MISSING] gemma-3-12b-it-qat-q4_0-unquantized/ (required, gated)")

    # Check incomplete downloads
    cache_dir = MODEL_DIR / ".cache"
    if cache_dir.exists():
        incompletes = list(cache_dir.rglob("*.incomplete"))
        if incompletes:
            print(f"\n=== In Progress ({len(incompletes)} file(s)) ===")
            for f in incompletes:
                size = format_size(f.stat().st_size)
                print(f"  {size} — {f.name[:40]}...")


def download_file(filename: str) -> bool:
    from huggingface_hub import hf_hub_download

    path = MODEL_DIR / filename
    if path.exists():
        print(f"  Already exists: {filename} ({format_size(path.stat().st_size)})")
        return True

    print(f"  Downloading: {filename}...")
    try:
        hf_hub_download(REPO_ID, filename, local_dir=str(MODEL_DIR))
        print(f"  Done: {filename}")
        return True
    except Exception as e:
        print(f"  FAILED: {filename} — {e}")
        return False


def download_gemma() -> bool:
    from huggingface_hub import snapshot_download

    gemma_path = MODEL_DIR / "gemma-3-12b-it-qat-q4_0-unquantized"
    if gemma_path.exists():
        print(f"  Already exists: gemma-3-12b-it-qat-q4_0-unquantized/")
        return True

    print(f"  Downloading: {GEMMA_REPO} (gated — login required)...")
    try:
        snapshot_download(GEMMA_REPO, local_dir=str(gemma_path))
        print(f"  Done: gemma-3-12b-it-qat-q4_0-unquantized/")
        return True
    except Exception as e:
        print(f"  FAILED: gemma — {e}")
        return False


def main() -> None:
    global MODEL_DIR

    parser = argparse.ArgumentParser(description="Download LTX-2.3 models")
    parser.add_argument("--status", action="store_true", help="Check download status")
    parser.add_argument("--list", action="store_true", help="List all downloadable files")
    parser.add_argument("--only", type=str, help="Download specific file (e.g., 'distilled', 'dev', 'gemma')")
    parser.add_argument("--model-dir", type=str, default=str(MODEL_DIR), help="Model directory")
    args = parser.parse_args()

    MODEL_DIR = Path(args.model_dir)
    MODEL_DIR.mkdir(parents=True, exist_ok=True)

    if args.status:
        check_status()
        return

    if args.list:
        print("Downloadable files:")
        for fname, desc, _ in DOWNLOADS:
            print(f"  {fname.split('.')[0].split('ltx-2.3-22b-')[-1] or fname.split('.')[0].split('ltx-2.3-')[-1]}: {desc}")
        print(f"  gemma: {GEMMA_DESC}")
        return

    # Map short names to filenames
    name_map = {}
    for fname, desc, _ in DOWNLOADS:
        # "ltx-2.3-22b-dev.safetensors" -> "dev"
        short = fname.replace("ltx-2.3-22b-", "").replace("ltx-2.3-", "").replace(".safetensors", "")
        name_map[short] = fname
    name_map["gemma"] = "gemma"

    if args.only:
        key = args.only.lower().replace("-", "_")
        if key == "gemma":
            ok = download_gemma()
            sys.exit(0 if ok else 1)
        elif key in name_map:
            ok = download_file(name_map[key])
            sys.exit(0 if ok else 1)
        else:
            print(f"Unknown file: {args.only}")
            print(f"Available: {', '.join(name_map.keys())}")
            sys.exit(1)

    # Download all sequentially
    print(f"Downloading all required models to: {MODEL_DIR}\n")
    results = {}
    for fname, desc, _ in DOWNLOADS:
        ok = download_file(fname)
        results[fname] = ok

    ok = download_gemma()
    results["gemma"] = ok

    print("\n" + "=" * 50)
    print("RESULTS")
    print("=" * 50)
    for name, status in results.items():
        mark = "OK" if status else "FAIL"
        print(f"  [{mark}] {name}")

    if not all(results.values()):
        sys.exit(1)


if __name__ == "__main__":
    main()
