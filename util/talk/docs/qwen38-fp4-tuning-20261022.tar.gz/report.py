import datetime
import hashlib
import json
from pathlib import Path
import tarfile

j = Path(__file__).resolve().parent
repo = Path('/home/edp1096/workspace/dgx_spark_init')
docs = repo/'util/talk/docs'
report_path = docs/'qwen38-fp4-tuning-20261022.json'
archive_path = report_path.with_suffix('.tar.gz')

def read(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

decision = read(j/'decision.json')
chosen = decision['label']
base_rows = {r['name']: r for r in read(j/'results/qualify-control/results.json')}
screen_rows = {r['name']: r for r in read(j/'results/baseline00/results.json')}
chosen_rows = read(j/'results'/chosen/'results.json')
equality = []
for row in chosen_rows:
    ref = base_rows.get(row['name'], screen_rows.get(row['name']))
    assert ref is not None, row['name']
    equality.append({'case': row['name'], 'text_equal': row['output_sha256'] == ref['output_sha256'],
                     'token_hash_equal': row['native_token_sha'] == ref['native_token_sha'],
                     'input_ids_equal': row['input_sha256'] == ref['input_sha256']})
assert all(all(v for k, v in row.items() if k != 'case') for row in equality)

pp = []
for row in chosen_rows:
    if row['kind'] != 'pp': continue
    ref = base_rows[row['name']]
    pp.append({'input_tokens': row['input_tokens'], 'before': ref['pp'], 'after': row['pp'],
               'improvement_percent': (row['pp']/ref['pp'] - 1)*100,
               'cached_tokens_before': ref['usage']['prompt_tokens_details']['cached_tokens'],
               'cached_tokens_after': row['usage']['prompt_tokens_details']['cached_tokens']})

screen = []
for path in sorted((j/'results').iterdir()):
    if not (path/'summary.json').exists(): continue
    entry = {'label': path.name, **read(path/'summary.json'), 'monitor': read(path/'monitor.json')}
    if (path/'equality.json').exists(): entry['equality'] = read(path/'equality.json')
    screen.append(entry)

checks = read(j/'correctness.json')
assert checks and all(r['passed'] for r in checks)
managed = read(j/'managed-holdout.json')
assert len(managed) == 4 and all(r['equal_control_text'] and r['equal_control_tokens'] and r['equal_warm'] for r in managed)
managed_tg = {}
for mode in ['off', 'medium', 'all']:
    group = [r for r in managed if mode == 'all' or r['mode'] == mode]
    numerator = sum(r['output_tokens']-1 for r in group)
    before = numerator / sum(base_rows[r['name']]['decode_s'] for r in group)
    after = numerator / sum(r['decode_s'] for r in group)
    managed_tg[mode] = {'before':before, 'after':after, 'change_percent':100*(after/before-1)}
talk = read(j/'fp4-final-talk-chat.json')
assert len(talk) == 2 and all(r['passed'] for r in talk)
compose = repo/'compose_yaml/qwen38_fn_fp4_local_tsfold/compose.yaml'
embedded = repo/'util/talk/internal/orchestrator/assets/compose.qwen-fp4-local.yaml'
assert compose.read_bytes() == embedded.read_bytes()
assert compose.stat().st_ino != embedded.stat().st_ino
assert sha(repo/'compose_yaml/qwen38_fn_fp4_local_tsfold/draft-vocab-korean.txt') == read(j/'preserved-profile.json')['vocab_sha256']

data = {
    'task': 'Qwen 3.8 Flash-Next FP4-Local PP/TG tuning on DGX Spark 61',
    'finished_at': datetime.datetime.now().astimezone().isoformat(),
    'outcome': 'Verified PP improvement; no additional TG improvement adopted.',
    'selected': decision,
    'unchanged': {'image': 'local/sparktalk-qwen38-fp4-tensorfold:db281878-ko2',
                  'engine': 'TensorFold native Zig/CUDA', 'tensor_parallel': 1,
                  'context_tokens': 1048576, 'kv_dtype': 'FP8', 'yarn': 4,
                  'mtp_max': 4, 'mtp_confidence': 'running product 0.4',
                  'draft_vocabulary_count': 86232,
                  'draft_vocabulary_sha256': sha(repo/'compose_yaml/qwen38_fn_fp4_local_tsfold/draft-vocab-korean.txt'),
                  'weights': 'Existing Huihui FP4-Local checkpoint, mounted read-only; no downloads or conversions.',
                  'vision': True, 'thinking': ['off', 'medium']},
    'method': {
        'pp': 'input tokens / backend prefill_seconds; cache disabled and cached_tokens == 0; identical complete input token IDs.',
        'tg': '(completion_tokens - 1) / backend decode time; reasoning tokens included; separate off/medium aggregates.',
        'screen': 'Greedy, seed 99, four prompts, 256 output tokens. Same 16K PP and Korean decode warmup before each arm.',
        'holdout': 'Eight fresh Korean/English/code/mixed prompts, seed 99, temperature 0.7, top_k 20, top_p 0.95, 512 tokens with ignore_eos. Each full case warmed and repeated; throughput test, not a task-quality score.',
        'cold_definition': 'Prompt cache disabled; existing OS page cache and compiled CUDA cache retained.',
        'timing_interference': 'No native/Go builds or Go tests ran concurrently with timed GPU requests.',
        'equality': 'Full answer/reasoning text SHA256 plus backend output token hash; input token IDs checked in full. API provides a 12-character output token hash, not full output IDs.',
        'memory': '0.2-second monitor, 2 GiB MemAvailable floor; all successful arms remained above the floor.',
        'scope': 'Host 61 only. Host 60 remained off and was not contacted. New cold-input tests reach 131072 tokens; 1M limit preserved, previous same-image 1M qualification not repeated here.',
    },
    'pp': pp,
    'managed_tg': {'results':managed_tg,
                   'note':'Four matched Korean/code prompts at 512 tokens, each warmed then repeated. The production runtime uses Docker bridge and its default enabled prompt cache; the control used host networking with prompt cache disabled. All measured managed requests nevertheless reported zero cached input tokens. The small observed decrease is reported as measured; this is not a controlled attribution to prefill chunk size or a TG improvement claim.',
                   'cases':[{'name':r['name'], 'tg':r['tg'], 'cached_tokens':r['cached_tokens'],
                             'text_equal_control':r['equal_control_text'], 'tokens_equal_control':r['equal_control_tokens']}
                            for r in managed]},
    'selected_case_equality': equality,
    'sampled_holdout_equality': read(j/'qualification-comparison.json'),
    'screening': screen,
    'excluded_diagnostic': {'label': 'baseline', 'reason': 'Initial harness token-boundary assertion (4097 vs 4096) before any timed result; fixed case preparation, then restarted as baseline00.'},
    'correctness': checks,
    'talk_chat': talk,
    'deployment': read(j/'deployment.json'),
    'checks': read(j/'checks.json'),
    'compose': {'standalone': str(compose.relative_to(repo)), 'embedded': str(embedded.relative_to(repo)),
                'equal_content_separate_files': True, 'sha256': sha(compose)},
    'sources': [
        'https://github.com/ashhart/TensorFold/tree/db281878ddb836fd0df510d8771ecb7e0fe47d26',
        'https://github.com/MiaAI-Lab/Qwen3.8-Flash-Next-Single-DGX-Spark-TensorFold',
        'compose_yaml/qwen38_fn_fp4_local_tsfold/compose.yaml',
    ],
}
with tarfile.open(archive_path, 'w:gz') as archive:
    for path in sorted(j.rglob('*')):
        if not path.is_file() or path.is_symlink(): continue
        relative = path.relative_to(j)
        if '__pycache__' in relative.parts or path.name in ['sparktalk', 'sparktalk.backup']:
            continue
        assert path.stat().st_size < 16*1024*1024, relative
        archive.add(path, arcname=str(relative), recursive=False)
data['raw_archive'] = {'path': str(archive_path.relative_to(repo)), 'sha256': sha(archive_path),
                       'bytes': archive_path.stat().st_size}
report_path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'report': str(report_path), 'archive': data['raw_archive'], 'pp': pp}, indent=2))
