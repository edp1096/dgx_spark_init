import json
import math
import subprocess
import sys
import time
from pathlib import Path

j = Path(__file__).resolve().parent
for _ in range(3600):
    if (j / 'EXTRA_COMPLETE').exists():
        break
    if (j / 'STOP').exists():
        raise SystemExit('Stopped')
    time.sleep(1)
else:
    raise TimeoutError('Extra screening')

def load(label, name):
    return json.loads((j / 'results' / label / name).read_text())

controls = [load(x, 'summary.json') for x in ['baseline-after', 'baseline-final']]
reference = {mode: math.sqrt(controls[0]['tg'][mode] * controls[1]['tg'][mode])
             for mode in ['off', 'medium']}
eligible = []
for profile in json.loads((j / 'extra-plan.json').read_text()):
    label = profile['label']
    if label.startswith('baseline') or not (j / 'results' / label / 'COMPLETE').exists():
        continue
    equality = load(label, 'equality.json')
    if not all(x['text_equal'] and x['token_hash_equal'] for x in equality.values()):
        continue
    summary = load(label, 'summary.json')
    ratio = {m: summary['tg'][m] / reference[m] for m in reference}
    score = math.sqrt(ratio['off'] * ratio['medium'])
    if score > 1.015 and min(ratio.values()) > .995:
        eligible.append((score, profile, ratio))

selected = max(eligible, key=lambda x: x[0]) if eligible else None
env = {'TF_FLASHNEXT_PREFILL_ROWS': '8192'}
if selected:
    env.update(selected[1]['env'])
selection = {'environment': env, 'tg_screen_reference': reference,
             'tg_candidate': selected, 'note': 'Screening only; holdout equality and speed still required.'}
(j / 'selection.json').write_text(json.dumps(selection, indent=2))
print('SELECTION', json.dumps(selection), flush=True)

env4 = {**env, 'TF_FLASHNEXT_PREFILL_ROWS': '4096'}
for label, overrides, suite in [('qualify-control', {}, 'qualify'),
                                ('qualify-candidate', env, 'qualify'),
                                ('qualify-4k', env4, 'pp-long')]:
    for _ in range(60):
        if subprocess.run(['docker', 'inspect', 'qwen38-fp4-tune-trial'],
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode:
            break
        time.sleep(1)
    else:
        raise RuntimeError('Prior trial remains')
    (j / 'status.json').write_text(json.dumps({'stage': 'qualification', 'label': label,
                                              'environment': overrides}, indent=2))
    print('QUALIFY_START', label, flush=True)
    with (j / (label + '.log')).open('w') as log:
        subprocess.run([sys.executable, '-u', str(j / 'arm.py'), label,
                        '--suite', suite, '--env', json.dumps(overrides)],
                       stdout=log, stderr=subprocess.STDOUT, check=True)
    print('QUALIFY_DONE', label, load(label, 'summary.json'), flush=True)

control = {x['name']: x for x in load('qualify-control', 'results.json')}
candidate = load('qualify-candidate', 'results.json')
comparison = {x['name']: {
    'text_equal': x['output_sha256'] == control[x['name']]['output_sha256'],
    'token_hash_equal': x['native_token_sha'] == control[x['name']]['native_token_sha'],
    'input_equal': x['input_sha256'] == control[x['name']]['input_sha256'],
    'pp_ratio': x['pp'] / control[x['name']]['pp'],
    'tg_ratio': x['tg'] / control[x['name']]['tg'],
} for x in candidate}
(j / 'qualification-comparison.json').write_text(json.dumps(comparison, indent=2))
print('QUALIFY_EQUAL', all(x['text_equal'] and x['token_hash_equal'] and x['input_equal']
                          for x in comparison.values()), flush=True)
(j / 'QUALIFY_COMPLETE').write_text(time.strftime('%FT%T%z'))
