import argparse
import copy
import hashlib
import json
import os
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

J = Path(__file__).resolve().parent
BASE = 'http://127.0.0.1:18026'
NAME = 'qwen38-fp4-tune-trial'
MODEL = 'edp1096/Huihui-Qwen3.8-Flash-Next-abliterated-FP4-Local'

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2))

def post(path, body):
    request = urllib.request.Request(BASE+path, data=json.dumps(body, ensure_ascii=False).encode(),
                                     headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(request, timeout=300) as response:
        return json.load(response)

def body(text, mode, cap=256, temperature=0):
    kw = {'enable_thinking':mode == 'medium'}
    if mode == 'medium':
        kw['reasoning_effort'] = 'medium'
    return {'model':MODEL, 'messages':[{'role':'user','content':text}],
            'chat_template_kwargs':kw, 'max_tokens':cap, 'temperature':temperature,
            'seed':99, 'top_k':20 if temperature else 0, 'top_p':.95 if temperature else 1,
            'stream':True, 'stream_options':{'include_usage':True}}

def tokenize(b):
    request = {k:b[k] for k in ['model','messages','chat_template_kwargs']}
    return post('/tokenize', {**request,'add_generation_prompt':True})['tokens']

def prepare_cases():
    prompts = [
        ('ko', '작업 코드 71-A. 코드 자체는 답변에서 생략하세요. 벡터 검색과 키워드 검색의 차이를 한국어로 여덟 문장 이상 설명하고, 두 방식을 함께 사용하는 구체적인 사례를 제시하세요.'),
        ('code', 'Task 71-B. Write a Python streaming UTF-8 line counter that handles chunk boundaries correctly. Explain its handling of incomplete byte sequences and include a small example.'),
    ]
    cases=[]
    for mode in ['off','medium']:
        for label,text in prompts:
            b=body(text,mode)
            ids=tokenize(b)
            cases.append({'name':label+'-'+mode,'mode':mode,'kind':'tg','body':b,'input_ids':ids})
    for target in [4096,16384,131072]:
        prefix=f'작업 코드 PP-{target}. 다음 합성 로그의 내용을 한 문장으로 설명하세요.\n'
        records=''.join(f'기록 {i:05d}: 처리 상태 정상, 지연 {i%73+3}ms, 메모리 점검 통과.\n' for i in range(9000))
        low,high=0,len(records)
        while low<high:
            mid=(low+high+1)//2
            if len(tokenize(body(prefix+records[:mid],'off',16)))<=target:
                low=mid
            else:
                high=mid-1
        text=prefix+records[:low]
        ids=tokenize(body(text,'off',16))
        for offset in range(-4,5):
            if len(ids)==target:break
            for suffix in ['', ' ', '\n', ' x', '\nx', '.', 'a']:
                trial=prefix+records[:max(0,low+offset)]+suffix
                trial_ids=tokenize(body(trial,'off',16))
                if len(trial_ids)==target:
                    text,ids=trial,trial_ids
                    break
        assert len(ids)==target,(target,len(ids))
        cases.append({'name':'pp-'+str(target),'mode':'off','kind':'pp',
                      'body':body(text,'off',16),'input_ids':ids})
    for c in cases:
        c['input_sha256']=hashlib.sha256(json.dumps(c['input_ids'],separators=(',',':')).encode()).hexdigest()
    write(J/'cases.json',cases)
    return cases

def measure(case, allow_cached=False):
    b=case['body']
    actual=tokenize(b)
    assert actual==case['input_ids'],case['name']
    native={};usage={};spec={};content=[];reasoning=[];finish=None
    started=time.perf_counter()
    request=urllib.request.Request(BASE+'/v1/chat/completions',data=json.dumps(b).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(request,timeout=300) as response:
        for raw in response:
            line=raw.decode().strip()
            if not line.startswith('data: {'):continue
            data=json.loads(line[6:])
            if data.get('error'):raise RuntimeError(data['error'])
            native=data.get('tensorfold') or native
            usage=data.get('usage') or usage
            spec=data.get('speculative') or spec
            for choice in data.get('choices',[]):
                delta=choice.get('delta') or {}
                content.append(delta.get('content') or '')
                reasoning.append(delta.get('reasoning_content') or delta.get('reasoning') or '')
                finish=choice.get('finish_reason') or finish
    n=usage['completion_tokens'];p=usage['prompt_tokens']
    cached=(usage.get('prompt_tokens_details') or {}).get('cached_tokens',0)
    assert allow_cached or cached==0,(case['name'],cached)
    assert p==len(actual)
    assert n>1 and native['tokens_per_second']>0
    answer=''.join(content);thought=''.join(reasoning)
    return {'name':case['name'],'mode':case['mode'],'kind':case['kind'],
            'input_tokens':p,'input_sha256':case['input_sha256'],'output_tokens':n,
            'answer':answer,'reasoning':thought,'finish_reason':finish,
            'output_sha256':hashlib.sha256(json.dumps([answer,thought,n],ensure_ascii=False).encode()).hexdigest(),
            'native_token_sha':native.get('token_sha'),'native':native,'speculative':spec,'usage':usage,
            'cached_tokens':cached,
            'wall_s':time.perf_counter()-started,'pp':(p-cached)/native['prefill_seconds'],
            'tg':native['tokens_per_second'],'decode_s':(n-1)/native['tokens_per_second']}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('label')
    parser.add_argument('--env',default='{}')
    parser.add_argument('--suite',choices=['screen','long','profile','qualify','tg','pp','pp-long','correctness'],default='screen')
    a=parser.parse_args()
    # The long-PP qualification also repeats the four original TG controls.
    # Keep the queued pp-long spelling as an alias for this combined suite.
    if a.suite == 'pp-long':
        a.suite = 'long'
    out=J/'results'/a.label
    out.mkdir(parents=True,exist_ok=False)
    service=json.loads((J/'service.json').read_text())
    env={**service['environment'],**json.loads(a.env)}
    cpuset=env.pop('BENCH_CPUSET',service.get('cpuset'))
    command=service['command'][:]
    command[command.index('--host')+1]='127.0.0.1'
    command[command.index('--port')+1]='18026'
    if a.suite != 'correctness':
        command += ['--prompt-cache-gib','0']
    cmd=['docker','run','-d','--name',NAME,'--gpus','all','--ipc','host','--network','host',
         '--security-opt','seccomp=unconfined','--memory','112g','--memory-swap','112g',
         '--ulimit','memlock=-1','--ulimit','stack=67108864',
         '-v',str(Path.home()/'.cache/huggingface'/MODEL)+':/model:ro',
         '-v',str(Path.home()/'.local/share/sparktalk/cache/qwen38-fp4-tensorfold')+':/cache']
    if cpuset:cmd+=['--cpuset-cpus',cpuset]
    for k,v in env.items():cmd+=['-e',str(k)+'='+str(v)]
    cmd += [service['image'],*command]
    write(out/'launch.json',{'command':cmd,'environment':env})
    running=subprocess.check_output(['docker','ps','--format','{{.Names}}'],text=True).splitlines()
    assert set(running)<= {'sparktalk-extra-media','sparktalk-extra-ssh','sparktalk-extra-collector','sparktalk-extra-documents'},running
    failure=[];done=threading.Event();began=time.monotonic();floor=1e9
    def watch():
        nonlocal floor
        while not done.wait(.2):
            available=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))/2**20
            floor=min(floor,available)
            if available<2 or time.monotonic()-began>1200:
                failure.append('memory floor or deadline')
                subprocess.run(['docker','stop','-t','2',NAME],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
                return
    worker=threading.Thread(target=watch,daemon=True)
    try:
        subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL)
        worker.start()
        for attempt in range(360):
            try:
                with urllib.request.urlopen(BASE+'/health',timeout=.5) as response:
                    health=json.load(response)
                break
            except Exception:
                assert not failure,failure
                state=subprocess.check_output(['docker','inspect','--format','{{.State.Running}}',NAME],text=True).strip()
                assert state=='true','trial exited'
                time.sleep(1)
        else:raise TimeoutError('startup')
        write(out/'health.json',health)
        print('READY',a.label,round(time.monotonic()-began,2),flush=True)
        if a.suite == 'correctness':
            subprocess.run([sys.executable, '-u', str(J/'correctness.py'), '--port', '18026',
                            '--output', str(out/'correctness.json')], check=True)
            assert not failure,failure
            (out/'COMPLETE').write_text(time.strftime('%FT%T%z'))
            print('DONE',a.label,'correctness',flush=True)
            return
        cases=json.loads((J/'cases.json').read_text()) if (J/'cases.json').exists() else prepare_cases()
        selected=[c for c in cases if c['name']!='pp-131072' or a.suite in ['long','pp-long']]
        if a.suite=='qualify':
            holdout=json.loads((J/'holdout.json').read_text())
            for c in holdout:
                ids=tokenize(c['body'])
                if 'input_ids' in c:assert c['input_ids']==ids
                c['input_ids']=ids
                c['input_sha256']=hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest()
            write(J/'holdout.json',holdout)
            selected=holdout+[c for c in cases if c['kind']=='pp']
        if a.suite in ['tg','pp']:selected=[c for c in selected if c['kind']==a.suite]
        if a.suite=='pp-long':selected=[c for c in selected if c['kind']=='pp']
        if a.suite=='profile':selected=[c for c in cases if c['name']=='pp-16384']
        # Warm the same longer prompt and a short decode before timing any candidate.
        for c in [next(c for c in cases if c['name']=='pp-16384'),cases[0]]:
            warm=copy.deepcopy(c)
            if warm['kind']=='tg':warm['body']['max_tokens']=512
            measure(warm)
        rows=[]
        for c in selected:
            warm_result=measure(c) if a.suite=='qualify' and c['kind']=='tg' else None
            row=measure(c)
            if warm_result is not None:
                row['warm_repeat_equal']=(row['output_sha256']==warm_result['output_sha256'] and row['native_token_sha']==warm_result['native_token_sha'])
                assert row['warm_repeat_equal'],c['name']
            rows.append(row);write(out/'results.json',rows)
            print('CASE',a.label,row['name'],'pp',round(row['pp'],2),'tg',round(row['tg'],2),
                  'tokens',row['output_tokens'],'spec',json.dumps(row['speculative']),flush=True)
        summary={}
        for mode in ['off','medium']:
            group=[r for r in rows if r['kind']=='tg' and r['mode']==mode]
            if group:summary[mode]=sum(r['output_tokens']-1 for r in group)/sum(r['decode_s'] for r in group)
        write(out/'summary.json',{'tg':summary,'pp':{r['name']:r['pp'] for r in rows if r['kind']=='pp'}})
        assert not failure,failure
        (out/'COMPLETE').write_text(time.strftime('%FT%T%z'))
        print('DONE',a.label,json.dumps(summary),flush=True)
    finally:
        done.set()
        if worker.is_alive():worker.join(2)
        with (out/'server.log').open('w') as log:
            subprocess.run(['docker','logs',NAME],stdout=log,stderr=subprocess.STDOUT)
        subprocess.run(['docker','stop','-t','10',NAME],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        subprocess.run(['docker','rm',NAME],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        write(out/'monitor.json',{'minimum_available_gib':floor,'failure':failure,'elapsed_s':time.monotonic()-began})

if __name__=='__main__':main()
