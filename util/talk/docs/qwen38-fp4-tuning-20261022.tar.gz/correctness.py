import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import time
import urllib.request

p = argparse.ArgumentParser()
p.add_argument('--port', default='18026')
p.add_argument('--output', required=True)
a = p.parse_args()
os.environ['API_URL'] = 'http://127.0.0.1:' + a.port
os.environ.pop('MODEL', None)
import client
import toolcheck

out = Path(a.output)
rows = []
def save(row):
    rows.append(row)
    out.write_text(json.dumps(rows, ensure_ascii=False, indent=2))
    print('CHECK', row['kind'], row.get('mode', ''), row['passed'], flush=True)
    assert row['passed'], row

def exact(r):
    return (r.content, r.reasoning, r.usage.get('completion_tokens'), r.token_sha)

def digest(r):
    return hashlib.sha256(json.dumps(exact(r), ensure_ascii=False).encode()).hexdigest()

original = client.chat
for mode in ['off', 'medium']:
    kw = {'enable_thinking': mode == 'medium'}
    if mode == 'medium': kw['reasoning_effort'] = 'medium'
    prompts = [
        ('arithmetic', 'Test V22A. What is 17 times 23? Reply with the number only.'),
        ('prose', '작업 V22B. 한국어로 KV 캐시의 역할을 여섯 문장으로 설명하세요.'),
        ('code', 'Test V22C. Write a short Python function that merges sorted integer lists.'),
        ('long-prefix', '검증 V22D. 아래 기록에서 비밀 코드를 찾으세요.\n' +
         ''.join(f'기록 {i:04d}: 지연 {i%37+1}ms, 상태 정상.\n' for i in range(900)) +
         '\n비밀 코드: KESTREL-9351\n비밀 코드만 답하세요.'),
    ]
    for name, text in prompts:
        messages = [{'role': 'user', 'content': text}]
        replies = [original(messages, max_tokens=512 if mode == 'medium' else 192,
                            temperature=0, seed=99, stream=True, timeout=180,
                            thinking_budget=96, chat_template_kwargs=kw, draft=draft)
                   for draft in [False, True, False]]
        cached = [r.cached_tokens for r in replies]
        passed = (exact(replies[0]) == exact(replies[1]) == exact(replies[2])
                  and cached[-1] is not None and cached[-1] > 0
                  and replies[0].tensorfold.get('drafts') is False
                  and replies[1].tensorfold.get('drafts') is True)
        if name == 'arithmetic': passed = passed and replies[0].content.strip() == '391'
        if name == 'long-prefix': passed = passed and replies[0].content.strip() == 'KESTREL-9351'
        save({'kind': 'serial-draft-cache', 'mode': mode, 'name': name,
              'passed': passed, 'cached_tokens': cached,
              'prompt_tokens': replies[0].prompt_tokens,
              'output_hashes': [digest(r) for r in replies],
              'answers': [r.content for r in replies],
              'native': [r.tensorfold for r in replies]})

    def chat(*args, **kwargs):
        kwargs.update(chat_template_kwargs=kw, thinking_budget=96, timeout=180,
                      max_tokens=max(1024, kwargs.get('max_tokens', 0)))
        return original(*args, **kwargs)
    client.chat = chat
    save({'kind': 'tool-call-stream-result', 'mode': mode,
          'passed': toolcheck.main() == 0})
    client.chat = original

    schema = {'type': 'object', 'properties': {'answer': {'type': 'integer'}},
              'required': ['answer'], 'additionalProperties': False}
    r = original([{'role': 'user', 'content': '17 times 23? Return JSON with an integer answer property.'}],
                 max_tokens=512, temperature=0, stream=True, timeout=180, thinking_budget=96,
                 chat_template_kwargs=kw,
                 response_format={'type': 'json_schema', 'json_schema': {
                     'name': 'answer', 'strict': True, 'schema': schema}})
    save({'kind': 'json-schema', 'mode': mode,
          'passed': json.loads(r.content) == {'answer': 391}, 'answer': r.content})

    # Existing local fixtures; no network requests or generated images.
    fixtures = Path(__file__).resolve().parent / 'fixtures'
    for name, prompt, expected in [('red', 'Name the solid image color. Reply RED or BLUE only.', 'RED'),
                                   ('ocr', 'Read the text exactly. Reply with the text only.', 'SPARK 7319')]:
        encoded = base64.b64encode((fixtures / (name + '.png')).read_bytes()).decode()
        r = original([{'role': 'user', 'content': [{'type': 'text', 'text': prompt},
                     {'type': 'image_url', 'image_url': {'url': 'data:image/png;base64,' + encoded}}]}],
                     temperature=0, max_tokens=512, thinking_budget=96, stream=True,
                     timeout=180, chat_template_kwargs=kw)
        save({'kind': 'vision-' + name, 'mode': mode, 'answer': r.content,
              'passed': r.content.strip() == expected})

kw = {'enable_thinking': False}
messages = [{'role': 'user', 'content': 'Remember the private test code WQ9826. Reply OK only.'}]
r = original(messages, temperature=0, max_tokens=32, timeout=120, chat_template_kwargs=kw)
messages += [{'role': 'assistant', 'content': r.content},
             {'role': 'user', 'content': 'What was the private test code? Reply with the code only.'}]
r = original(messages, temperature=0, max_tokens=64, timeout=120, chat_template_kwargs=kw)
save({'kind': 'conversation-resume', 'passed': r.content.strip() == 'WQ9826', 'answer': r.content})

body = client.chat_body([{'role': 'user', 'content': '한국어로 우주 도서관에 관한 소설을 스무 문단 이상 작성하세요.'}],
                        stream=True, max_tokens=2048, temperature=0, chat_template_kwargs=kw)
req = urllib.request.Request(os.environ['API_URL'] + '/v1/chat/completions',
                             json.dumps(body).encode(), {'Content-Type': 'application/json'})
seen = False
with urllib.request.urlopen(req, timeout=120) as response:
    for raw in response:
        if not raw.startswith(b'data: {'): continue
        data = json.loads(raw[6:])
        if any((c.get('delta') or {}).get('content') for c in data.get('choices', [])):
            seen = True
            break
assert seen
started = time.monotonic()
while client.get_json('/health').get('busy', False):
    assert time.monotonic() - started < 30, 'Cancellation did not clear'
    time.sleep(.1)
r = original([{'role': 'user', 'content': '17 times 23? Reply with the number only.'}],
             temperature=0, max_tokens=64, timeout=120, chat_template_kwargs=kw)
save({'kind': 'cancel-recover', 'passed': r.content.strip() == '391', 'answer': r.content})
