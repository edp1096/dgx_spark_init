import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import time
import urllib.request

j = Path(__file__).resolve().parent
dist = Path('/home/edp1096/workspace/dgx_spark_init/util/talk/dist/sparktalk-linux-arm64')
name = 'sparktalk-qwen38-fp4-local'
base = 'http://127.0.0.1:8585'

def api(path, method='GET'):
    req = urllib.request.Request(base+path, data=b'' if method == 'POST' else None, method=method)
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.load(r)

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(): (j/'deployment.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))

cfg = api('/api/config')
assert cfg['runtime']['auto_start'] is False
running = subprocess.check_output(['docker','ps','--format','{{.Names}}'], text=True).splitlines()
assert set(running) <= {'sparktalk-extra-media','sparktalk-extra-ssh'}, running
shutil.copy2(dist, j/'sparktalk.backup')
result = {'before_binary_sha256': digest(dist), 'after_binary_sha256': digest(j/'sparktalk'),
          'host': '61', 'host60_contacted': False, 'checks': []}
new = dist.with_name('sparktalk-fp4-tune.new')
assert not new.exists()
shutil.copy2(j/'sparktalk', new)
new.chmod(0o755)
new.replace(dist)
save()
subprocess.run(['systemctl','--user','restart','sparktalk-trial-restore.service'], check=True)
for _ in range(120):
    try:
        cfg = api('/api/config')
        assert cfg['runtime']['auto_start'] is False
        break
    except Exception: time.sleep(1)
else: raise TimeoutError('Talk restart')
print('TALK_RESTARTED', flush=True)

done = threading.Event()
failure = []
minimum = 1e9
started = time.monotonic()
def watch():
    global minimum
    while not done.wait(.2):
        available = int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines()
                             if x.startswith('MemAvailable:')))/2**20
        minimum = min(minimum, available)
        if available < 2 or time.monotonic()-started > 1200:
            failure.append('Memory floor/deadline')
            subprocess.run(['docker','stop','-t','2',name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
thread = threading.Thread(target=watch, daemon=True)
thread.start()
try:
    api('/api/runtime/bundles/flash-next-fp4-local/start', 'POST')
    for _ in range(600):
        op = api('/api/runtime').get('operation') or {}
        assert not failure, failure
        assert op.get('bundle_id') == 'flash-next-fp4-local', op
        if op.get('state') != 'running': break
        time.sleep(2)
    else: raise TimeoutError('Managed start')
    result['start_operation'] = op
    save()
    assert op['state'] == 'complete', op
    print('MANAGED_FP4_READY', flush=True)
    inspected = json.loads(subprocess.check_output(['docker','inspect',name], text=True))[0]
    env = dict(x.split('=',1) for x in inspected['Config']['Env'])
    assert env['TF_FLASHNEXT_PREFILL_ROWS'] == '4096'
    assert env['TF_FLASHNEXT_DEPTH'] == '4'
    assert 'TF_FLASHNEXT_MTP_Q4' not in env
    command = inspected['Config']['Cmd']
    assert command[command.index('--context')+1] == '1048576'
    assert command[command.index('--kv-dtype')+1] == 'fp8'
    assert '--prompt-cache-gib' not in command
    assert next(x for x in inspected['Mounts'] if x['Destination']=='/model')['RW'] is False
    result['runtime'] = {'image': inspected['Config']['Image'], 'image_id': inspected['Image'],
                         'command': command, 'environment': {k:v for k,v in env.items()
                          if k.startswith(('TF_FLASHNEXT_', 'TENSORFOLD_'))}, 'model_readonly': True}
    save()
    tasks = [
        ('correctness', ['correctness.py','--port','18004','--output',str(j/'correctness.json')]),
        ('managed-holdout', ['managed-holdout.py']),
        ('talk-chat', ['talk-chat-smoke.py','flash-next-fp4-local','fp4-final']),
    ]
    for label, args in tasks:
        print('VERIFY_START', label, flush=True)
        with (j/(label+'.log')).open('w') as log:
            subprocess.run([sys.executable,'-u',str(j/args[0]),*args[1:]],
                           stdout=log, stderr=subprocess.STDOUT, check=True)
        assert not failure, failure
        result['checks'].append({'label':label, 'passed':True})
        save()
        print('VERIFY_DONE', label, flush=True)
    for _ in range(30):
        state = json.loads(subprocess.check_output(['docker','inspect',name],text=True))[0]['State']
        if state.get('Health',{}).get('Status') == 'healthy': break
        time.sleep(2)
    assert state['Running'] and state['Health']['Status']=='healthy', state
    result['container_state'] = {'running':True,'health':'healthy'}
    cfg = api('/api/config')
    assert cfg['model']['endpoint'].rstrip('/') == 'http://127.0.0.1:18004'
    result['talk_model'] = {k:cfg['model'].get(k) for k in ['default_model','endpoint','model_type']}
    result['passed'] = True
    print('DEPLOY_COMPLETE', flush=True)
finally:
    done.set()
    thread.join(2)
    result['monitor'] = {'minimum_available_gib':minimum, 'failure':failure,
                         'elapsed_s':time.monotonic()-started}
    save()
