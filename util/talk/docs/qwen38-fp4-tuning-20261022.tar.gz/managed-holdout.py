import json
from pathlib import Path
import arm

j = Path(__file__).resolve().parent
arm.BASE = 'http://127.0.0.1:18004'
control = {r['name']: r for r in json.loads((j/'results/qualify-control/results.json').read_text())}
rows = []
selected = {'holdout-ko-off', 'holdout-code-off', 'holdout-ko-medium', 'holdout-code-medium'}
for case in json.loads((j/'holdout.json').read_text()):
    if case['name'] not in selected:
        continue
    warm = arm.measure(case, allow_cached=True)
    row = arm.measure(case, allow_cached=True)
    ref = control[case['name']]
    row['equal_control_text'] = row['output_sha256'] == ref['output_sha256']
    row['equal_control_tokens'] = row['native_token_sha'] == ref['native_token_sha']
    row['equal_warm'] = row['output_sha256'] == warm['output_sha256'] and row['native_token_sha'] == warm['native_token_sha']
    rows.append(row)
    arm.write(j/'managed-holdout.json', rows)
    print('MANAGED_HOLDOUT', case['name'], round(row['tg'], 2),
          'cached', row['cached_tokens'], row['equal_control_text'], row['equal_control_tokens'], flush=True)
    assert row['equal_control_text'] and row['equal_control_tokens'] and row['equal_warm'], case['name']
summary = {}
for mode in ['off', 'medium']:
    group = [r for r in rows if r['mode'] == mode]
    summary[mode] = sum(r['output_tokens']-1 for r in group) / sum(r['decode_s'] for r in group)
arm.write(j/'managed-holdout-summary.json', summary)
