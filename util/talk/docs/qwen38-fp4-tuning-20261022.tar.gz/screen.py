import json
import subprocess
import sys
import time
import argparse
from pathlib import Path

j=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--plan',default='screen-plan.json')
parser.add_argument('--wait',default='results/baseline00/COMPLETE')
parser.add_argument('--marker',default='SCREEN_COMPLETE')
args=parser.parse_args()
for _ in range(3600):
    if (j/args.wait).exists():break
    monitor=j/'results/baseline00/monitor.json'
    if args.wait=='results/baseline00/COMPLETE' and monitor.exists():raise RuntimeError('Baseline did not complete')
    time.sleep(1)
else:raise TimeoutError('Baseline')
reference={r['name']:r for r in json.loads((j/'results/baseline00/results.json').read_text())}
plan=json.loads((j/args.plan).read_text())
for profile in plan:
    if (j/'STOP').exists():break
    # The preceding arm records COMPLETE before its container finishes stopping.
    for _ in range(60):
        if subprocess.run(['docker','inspect','qwen38-fp4-tune-trial'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:break
        time.sleep(1)
    else:raise RuntimeError('Prior trial still exists')
    print('SCREEN_START',profile['label'],flush=True)
    (j/'status.json').write_text(json.dumps({'stage':'screening','profile':profile,'time':time.strftime('%FT%T%z')},indent=2))
    with (j/(profile['label']+'.log')).open('w') as log:
        p=subprocess.run([sys.executable,'-u',str(j/'arm.py'),profile['label'],
                          '--suite',profile['suite'],'--env',json.dumps(profile['env'])],stdout=log,stderr=subprocess.STDOUT)
    out=j/'results'/profile['label']
    if (out/'monitor.json').exists():
        assert not json.loads((out/'monitor.json').read_text())['failure'],'Memory floor/deadline reached'
    if p.returncode:
        print('SCREEN_FAILED',profile['label'],p.returncode,flush=True)
        continue
    rows=json.loads((out/'results.json').read_text())
    equal={r['name']:{'text_equal':r['output_sha256']==reference[r['name']]['output_sha256'],
                      'token_hash_equal':r['native_token_sha']==reference[r['name']]['native_token_sha']}
           for r in rows}
    (out/'equality.json').write_text(json.dumps(equal,indent=2))
    print('SCREEN_DONE',profile['label'],(out/'summary.json').read_text(),
          'equal',all(v['text_equal'] and v['token_hash_equal'] for v in equal.values()),flush=True)
(j/args.marker).write_text(time.strftime('%FT%T%z'))
