import json,urllib.request,time,pathlib,sys,hashlib,os
base='http://127.0.0.1:8585';root=pathlib.Path(__file__).resolve().parent;bundle=sys.argv[1];label=sys.argv[2]
def api(path,method='GET',body=None):
 req=urllib.request.Request(base+path,method=method,data=json.dumps(body).encode() if body is not None else None,headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=120) as f:
  payload=f.read();return json.loads(payload) if payload else None
start=time.monotonic()
while True:
 op=api('/api/runtime').get('operation',{})
 if op.get('state')!='running':
  break
 assert time.monotonic()-start<600,op
 time.sleep(1)
c=api('/api/config');assert c['model']['model_type']=='qwen3.8-tensorfold',c['model']['model_type'];model=c['model']['default_model'];result_path=root/(label+'-talk-chat.json');rows=json.loads(result_path.read_text()) if result_path.exists() else []
port={'flash-next-fp4-local':18004,'qwen38fn_exl3':18002}[bundle]
assert c['model']['endpoint'].rstrip('/')==f'http://127.0.0.1:{port}',c['model']['endpoint']
with urllib.request.urlopen(f'http://127.0.0.1:{port}/health',timeout=15) as f: assert f.status==200
for mode in os.environ.get('TALK_SMOKE_MODES','off,medium').split(','):
 rows=[row for row in rows if row['mode']!=mode]
 s=api('/api/sessions','POST',{'title':'Disposable TensorFold qualification '+label+' '+mode,'model':model,'reasoning_effort':mode})
 answer='';thought='';perf=None;events=[];kind=''
 try:
  req=urllib.request.Request(base+'/api/chat',data=json.dumps({'session_id':s['id'],'content':'17 곱하기 23은? 정답 숫자만 답하세요.','model':model,'reasoning_effort':mode,'tools_enabled':False}).encode(),headers={'Content-Type':'application/json'})
  with urllib.request.urlopen(req,timeout=300) as response:
   for raw in response:
    line=raw.decode().strip()
    if line.startswith('event: '):kind=line[7:]
    if not line.startswith('data: '):continue
    value=json.loads(line[6:]);events.append(kind)
    if kind=='delta':answer+=value if isinstance(value,str) else value.get('content',value.get('delta',''))
    if kind in ('reasoning','reasoning_delta'):thought+=value if isinstance(value,str) else value.get('content',value.get('delta',''))
    if kind=='performance':perf=value
    if kind=='error':raise RuntimeError(str(value))
  assert answer.strip()=='391',repr(answer)
  assert perf and perf.get('finish_status')=='completed' and perf.get('pp',0)>0 and perf.get('tg',0)>0,perf
  rows.append({'model':model,'mode':mode,'answer':answer,'reasoning_chars':len(thought),'reasoning_sha256':hashlib.sha256(thought.encode()).hexdigest(),'performance':perf,'events':sorted(set(events)),'passed':True})
  (root/(label+'-talk-chat.json')).write_text(json.dumps(rows,ensure_ascii=False,indent=2));print({'mode':mode,'answer':answer,'events':sorted(set(events)),'performance':perf},flush=True)
 finally:api('/api/sessions/'+s['id'],'DELETE')
by_mode={row['mode']:row for row in rows}
if 'off' in by_mode and 'medium' in by_mode: assert by_mode['medium']['performance']['output_tokens']>by_mode['off']['performance']['output_tokens'],rows
