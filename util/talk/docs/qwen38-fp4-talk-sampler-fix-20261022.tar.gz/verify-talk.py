import hashlib
import argparse
import json
from pathlib import Path
import time
import urllib.request

j = Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--repeat-identity',action='store_true')
args=parser.parse_args()
base = 'http://127.0.0.1:8585'
model = 'edp1096/Huihui-Qwen3.8-Flash-Next-abliterated-FP4-Local'

def api(path, method='GET', body=None):
    req = urllib.request.Request(base+path, method=method,
        data=json.dumps(body).encode() if body is not None else None,
        headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req, timeout=30) as r:
        raw=r.read()
        return json.loads(raw) if raw else None

for _ in range(180):
    op=api('/api/runtime').get('operation') or {}
    if op.get('state')!='running':
        assert op.get('state')=='complete',op
        break
    time.sleep(1)
else:raise TimeoutError('Model startup')

sid='chat-1792604990226353162'
original=api('/api/sessions/'+sid+'/messages')
original_messages=original if isinstance(original,list) else original['messages']
original_user=next(m for m in original_messages if m['role']=='user')
metadata=next(s for s in api('/api/sessions') if s['id']==sid)
original_effort=metadata.get('reasoning_effort') or 'medium'
original_perf=next(m['performance'] for m in original_messages if m['role']=='assistant' and m.get('performance'))
cases=[('original-identity-replay',original_effort,original_user['content']),
       ('prose-off','off','한국어로 RAM과 SSD의 차이와 각자의 역할을 여덟 문장 이상 설명하세요. 외부 검색은 필요하지 않습니다.'),
       ('prose-medium','medium','한국어로 RAM과 SSD의 차이와 각자의 역할을 여덟 문장 이상 설명하세요. 외부 검색은 필요하지 않습니다.')]
rows=[]
if args.repeat_identity:
    cases=[('original-identity-warm-replay',original_effort,original_user['content'])]
    rows=json.loads((j/'talk-verification.json').read_text())
for name,mode,text in cases:
    session=api('/api/sessions','POST',{'title':'Disposable FP4 real Talk verification '+name,
                'model':model,'reasoning_effort':mode})
    events=[];perf=None;content=[];reasoning=[];kind=''
    try:
        body={'session_id':session['id'],'content':text,'model':model,
              'reasoning_effort':mode,'tools_enabled':True}
        req=urllib.request.Request(base+'/api/chat',data=json.dumps(body).encode(),
                                  headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=180) as response:
            for raw in response:
                line=raw.decode().strip()
                if line.startswith('event: '):kind=line[7:]
                if not line.startswith('data: '):continue
                value=json.loads(line[6:]);events.append(kind)
                if kind=='error':raise RuntimeError(str(value))
                if kind=='performance':perf=value
                if kind=='delta':content.append(value if isinstance(value,str) else value.get('content',value.get('delta','')))
                if kind in ['reasoning','reasoning_delta']:
                    reasoning.append(value if isinstance(value,str) else value.get('content',value.get('delta','')))
        answer=''.join(content);thought=''.join(reasoning)
        assert answer.strip(),name
        assert perf and perf.get('finish_status')=='completed' and perf.get('tg',0)>0,perf
        row={'case':name,'mode':mode,'tools_enabled':True,
             'transport':'Actual running Talk /api/chat; no temperature, sampler, seed, output-limit or system-prompt overrides.',
             'user_text_sha256':hashlib.sha256(text.encode()).hexdigest(),
             'answer_sha256':hashlib.sha256(answer.encode()).hexdigest(),'answer_chars':len(answer),
             'reasoning_chars':len(thought),'performance':perf,'events':sorted(set(events))}
        if name.startswith('original-identity'):
            row['before']=original_perf
            row['comparison_scope']='Same original user text/model/reasoning mode replayed in a new disposable Talk session. Same current user settings; cache/memory context and stochastic outputs can differ. Original conversation untouched.'
        rows.append(row)
        (j/'talk-verification.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
        print(json.dumps({'case':name,'mode':mode,'performance':perf},ensure_ascii=False),flush=True)
    finally:api('/api/sessions/'+session['id'],'DELETE')

prose=[row for row in rows if row['case'].startswith('prose-')]
assert len(prose)==2
for row in prose:
    perf=row['performance']
    assert row['tools_enabled'] and perf['prompt_tokens']>=5000
    assert perf['output_tokens']>=128 and perf['tg']>=25,(row['case'],perf)
print('PASS actual Talk throughput: off and medium, tools enabled, >=128 output tokens, >=25 tok/s.',flush=True)
