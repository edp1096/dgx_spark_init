import hashlib
import json
import tarfile
from datetime import datetime, timezone
from pathlib import Path

j = Path(__file__).resolve().parent
repo = Path('/home/edp1096/workspace/dgx_spark_init')
out = repo/'util/talk/docs/qwen38-exl3-mtp789-20261022.json'
rows = json.loads((j/'results.json').read_text())
assert (j/'COMPLETE').exists() and len(rows) == 8
before, after = rows[0], rows[-1]
baselines = {}
for mode in ['off', 'medium']:
    cases = [c for arm in [before, after] for c in arm['cases'] if c['mode'] == mode]
    baselines[mode] = sum(len(c['output_ids'])-1 for c in cases)/sum(c['stats']['decode_s'] for c in cases)
summary = []
for arm in rows:
    entry = {k: arm[k] for k in ['label','depth','confidence']}
    entry['modes'] = {mode: {**s, 'gain_percent_vs_bracketed_baseline':100*(s['tg']/baselines[mode]-1)}
                      for mode,s in arm['summary'].items()}
    entry['all_output_ids_identical'] = all(c['same_output_as_baseline'] for c in arm['cases'])
    entry['measured_graph_captures'] = sum(c['graph_captures'] for c in arm['cases'])
    summary.append(entry)
restored = json.loads((j/'runtime-restored.json').read_text())
assert restored['selected_bundle'] == 'qwen38fn_exl3'
assert restored['operation']['state'] == 'complete'
profile = json.loads(Path('/home/edp1096/.local/share/sparktalk/cache/qwen38-exl3-tensorfold/runtime-profile.json').read_text())
assert profile['depth'] == 5 and profile['confidence'] == .4 and profile['draft_vocabulary'] == 86218
vocab_identity = json.loads((j/'vocab-identity.json').read_text())
assert vocab_identity['same_as_previous']
archive = out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as tf:
    for name in ['bench.py','run.py','report.py','cases.json','command.json','results.json','bench.log','COMPLETE','vocab-identity.json']:
        tf.add(j/name,arcname=name)
report = {
    'status':'complete-and-restored', 'host':'61 only; host 60 untouched',
    'finished_utc':datetime.now(timezone.utc).isoformat(),
    'conditions':{
        'image':'local/sparktalk-qwen38-exl3-tensorfold:db281878-tune1',
        'weights_changed':False,'draft_vocabulary_changed':False,'draft_vocabulary':86218,
        'context':1048576,'kv':'int8','vision':True,'streams':2,
        'expert_tiles':'compact-parallel-v1','moe_window':2048,
        'temperature':.7,'top_k':20,'top_p':.95,'seed':99,
        'cases':'Korean explanation and English code, each thinking off and medium',
        'output_tokens_per_case':256,'stop_eos':False,
        'timing':'TG=(output_tokens-1)/native decode_s; all cold-prefix; all measured graph captures zero',
        'isolation':'Bundle auxiliaries stopped, shared weights loaded once, decoder and CUDA graphs rebuilt for each depth; confidence changed between arms at the same depth',
        'warmup':'768-token discarded run per arm, repeat measured case if capture occurred',
    },
    'baseline_bracket_weighted_tg':baselines,'results':summary,'vocabulary_identity':vocab_identity,
    'production_restored':{
        'mtp_max':5,'confidence':.4,'selected_bundle':restored['selected_bundle'],
        'operation_state':restored['operation']['state'],
        'components':[{k:c.get(k) for k in ['id','status','health']} for c in restored['components']],
        'runtime_profile':profile,
    },
    'limits':['Short TG screening, 4 cases per arm, not a long-context or universal speed claim.',
              'One sample per candidate case, current profile measured before and after. Small differences are not conclusive.'],
    'artifact':{'file':str(archive.relative_to(repo)),
                'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size},
    'source':'https://github.com/ashhart/TensorFold/tree/db281878ddb836fd0df510d8771ecb7e0fe47d26',
}
out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(out)
print(json.dumps({'baseline':baselines,'results':summary},ensure_ascii=False,indent=2))
