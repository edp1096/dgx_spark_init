import gc
import hashlib
import json
import os
import sys
import time
from pathlib import Path

import torch
from tokenizers import Tokenizer

sys.path.insert(0, '/opt/sparktalk-qwen-exl3')
from compact_experts import install as compact
from parallel_group import install as grouping
from tensorfold.engine.exact_sampling import Sampling
from tensorfold.families.qwen4_exp.cuda import engine as module, exl3_mm, exl3_pack
from tensorfold.families.qwen4_exp.cuda.engine import FlashNextEngine
from tensorfold.families.qwen4_exp.cuda.graphs import Graphs
from tensorfold.families.qwen4_exp.cuda.multi import MultiDecoder
from tensorfold.cuda.scheduler import Scheduler

j = Path('/job')
module.KEEP = 1
compact()
grouping()
exl3_mm.MOE_WINDOW = exl3_pack.MOE_WINDOW = 2048
os.environ['TENSORFOLD_VISION_WEIGHTS'] = '/runtime/exl3-vision-f16.safetensors'
metrics = {'captures': 0, 'seconds': 0.0}
original_capture = Graphs._capture

def capture(self, fn):
    started = time.perf_counter()
    result = original_capture(self, fn)
    metrics['captures'] += 1
    metrics['seconds'] += time.perf_counter() - started
    return result

Graphs._capture = capture
cases = json.loads((j / 'cases.json').read_text())
tok = Tokenizer.from_file('/runtime/model-yarn4/tokenizer.json')
rows = []
engine = None

def clear():
    m = engine.multi
    assert not m.streams and not m.filling
    states = {id(k[1]): k[1] for k in m.kept}
    m.kept.clear()
    m.passed.clear()
    for state in states.values():
        if all(f is not state for f in m.free):
            m.free.append(state)
    if m.solo is not None:
        preferred = m.solo.st
        if any(f is preferred for f in m.free):
            m.free = [f for f in m.free if f is not preferred] + [preferred]

def generate(case, count):
    clear()
    ids = []
    before = dict(metrics)
    started = time.perf_counter()
    stats = engine.generate(case['input_ids'], count,
                            Sampling(seed=case['seed'], temperature=.7, top_k=20, top_p=.95),
                            lambda new: ids.extend(new), draft=True, stop_eos=False)
    elapsed = time.perf_counter() - started
    assert stats['cached'] == 0
    assert len(ids) == count
    return {'name': case['name'], 'mode': case['mode'], 'output_ids': ids,
            'output_sha256': hashlib.sha256(json.dumps(ids).encode()).hexdigest(),
            'text': tok.decode(ids, skip_special_tokens=False), 'stats': stats,
            'tg': (len(ids)-1)/stats['decode_s'], 'wall_s': elapsed,
            'graph_captures': metrics['captures']-before['captures'],
            'graph_capture_s': metrics['seconds']-before['seconds']}

def set_profile(depth, confidence):
    if engine.depth != depth:
        engine.close()
        engine.multi = None
        gc.collect()
        torch.cuda.synchronize()
        torch.cuda.empty_cache()
        engine.depth = depth
        engine.confidence = confidence
        engine.multi = MultiDecoder(engine.w, slots=2, capacity=engine.max_len, depth=depth,
                                    confidence=confidence, keep=1, points=engine.points,
                                    kv_dtype='int8', share=0.0, vision=engine.vision,
                                    prefill_rows=engine.prefill_rows, workspace_bytes=0, graphs=True)
        engine.multi.warm()
        engine.scheduler = Scheduler(engine.multi, max_streams=2)
    else:
        engine.confidence = engine.multi.confidence = confidence

try:
    started = time.perf_counter()
    engine = FlashNextEngine(Path('/runtime/model-yarn4'), depth=9, confidence=.4,
                             draft_vocab='/runtime/qwen38-exl3-ko-draft-vocab.txt',
                             max_len=1048576, context_explicit=True, kv_dtype='int8',
                             streams=2, graphs=True, vision=True, prefetch=False)
    for table in {id(layer.ple.table): layer.ple.table for layer in engine.w.layers
                  if layer.ple is not None}.values():
        table.prefetch()
    print('ENGINE_READY', time.perf_counter()-started, flush=True)
    profiles = [(5,.4,'baseline-before'), (7,0.,'fixed7'), (7,.4,'gated7'),
                (8,0.,'fixed8'), (8,.4,'gated8'), (9,0.,'fixed9'),
                (9,.4,'gated9'), (5,.4,'baseline-after')]
    reference = {}
    for depth, confidence, label in profiles:
        print('PROFILE_START', label, flush=True)
        set_profile(depth, confidence)
        # Fill a larger slot once so measured requests do not resize/capture graphs.
        generate(cases[0], 768)
        arm = {'label': label, 'depth': depth, 'confidence': confidence, 'cases': []}
        for case in cases:
            result = generate(case, case['max_tokens'])
            if result['graph_captures']:
                # Captures are excluded by repeating exactly the same cold-prefix case.
                result = generate(case, case['max_tokens'])
            assert result['graph_captures'] == 0
            if label == 'baseline-before':
                reference[case['name']] = result['output_ids']
            result['same_output_as_baseline'] = result['output_ids'] == reference[case['name']]
            assert result['same_output_as_baseline'], (label, case['name'])
            arm['cases'].append(result)
            print('CASE', label, case['name'], round(result['tg'],3),
                  result['stats'].get('accepted'), result['stats'].get('drafted'), flush=True)
        arm['summary'] = {}
        for mode in ['off','medium']:
            group = [r for r in arm['cases'] if r['mode'] == mode]
            arm['summary'][mode] = {'tg': sum(len(r['output_ids'])-1 for r in group)/sum(r['stats']['decode_s'] for r in group),
                                    'accepted': sum(r['stats'].get('accepted',0) for r in group),
                                    'drafted': sum(r['stats'].get('drafted',0) for r in group)}
        rows.append(arm)
        (j/'results.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2))
        print('PROFILE_DONE', label, json.dumps(arm['summary']), flush=True)
    (j/'COMPLETE').write_text(time.strftime('%FT%T%z'))
finally:
    if engine is not None:
        engine.close()
