import json
import subprocess
import time
import urllib.request
from pathlib import Path

j = Path(__file__).resolve().parent
base = 'http://127.0.0.1:8585/api/runtime'
name = 'qwen38-mtp789-trial'

def api(path='', method='GET'):
    req = urllib.request.Request(base+path, method=method)
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.load(r)

def wait_operation(timeout):
    started = time.monotonic()
    while time.monotonic()-started < timeout:
        status = api()
        op = status.get('operation', {})
        if op.get('state') == 'complete':
            return status
        if op.get('state') in ['error', 'failed']:
            raise RuntimeError(op)
        time.sleep(2)
    raise TimeoutError('Talk operation did not finish')

before = api()
assert before['selected_bundle'] == 'qwen38fn_exl3'
assert before.get('operation',{}).get('state') not in ['running','pending']
(j/'runtime-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2))
cmd = ['docker','run','--rm','--name',name,'--gpus','all','--ipc','host',
       '--cpuset-cpus','5-9,15-19','--memory','112g','--memory-swap','112g',
       '--security-opt','seccomp=unconfined','--entrypoint','python3',
       '-e','PYTHONUNBUFFERED=1','-e','HF_HUB_OFFLINE=1','-e','TRANSFORMERS_OFFLINE=1',
       '-e','TENSORFOLD_NO_UPDATE_CHECK=1','-e','TENSORFOLD_MEMORY_RESERVE_GIB=4',
       '-e','OMP_NUM_THREADS=4','-e','MAX_JOBS=1','-e','TORCH_CUDA_ARCH_LIST=12.1',
       '-e','TORCH_EXTENSIONS_DIR=/runtime/torch-extensions',
       '-e','TRITON_CACHE_DIR=/runtime/triton',
       '-v',str(j)+':/job',
       '-v','/home/edp1096/.cache/huggingface:/hf:ro',
       '-v','/home/edp1096/.local/share/sparktalk/cache/qwen38-exl3-tensorfold:/runtime',
       'local/sparktalk-qwen38-exl3-tensorfold:db281878-tune1','-u','/job/bench.py']
(j/'command.json').write_text(json.dumps(cmd,indent=2))
try:
    api('/bundles/qwen38fn_exl3/stop','POST')
    wait_operation(180)
    print('BUNDLE_STOPPED', flush=True)
    with (j/'bench.log').open('w') as log:
        p = subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
        start = time.monotonic()
        while p.poll() is None:
            mem = {x.split(':')[0]:int(x.split()[1])*1024 for x in Path('/proc/meminfo').read_text().splitlines()}
            if mem['MemAvailable'] < 2*1024**3:
                raise RuntimeError('Memory floor')
            if time.monotonic()-start > 900:
                raise TimeoutError('Trial exceeded 15 minutes')
            time.sleep(1)
        if p.returncode:
            raise RuntimeError(f'Trial failed, exit {p.returncode}')
    print('BENCH_COMPLETE', flush=True)
finally:
    subprocess.run(['docker','stop','--time','10',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    print('RESTORING', flush=True)
    api('/bundles/qwen38fn_exl3/start','POST')
    restored = wait_operation(900)
    (j/'runtime-restored.json').write_text(json.dumps(restored, ensure_ascii=False, indent=2))
    print('RESTORED', flush=True)
