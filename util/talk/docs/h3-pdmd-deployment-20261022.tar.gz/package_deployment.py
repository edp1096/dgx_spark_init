import hashlib
import json
import shutil
import subprocess
import tarfile
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

root=Path('/home/edp1096/.cache/sparktalk/experiments/h3-pdmd')
private=root/'deployment'
repo=Path('/home/edp1096/workspace/dgx_spark_init')
docs=repo/'util/talk/docs'
def get(path):return json.load(urllib.request.urlopen('http://127.0.0.1:'+path,timeout=10))
cfg=get('8585/api/config');runtime=get('8585/api/runtime');health=get('8730/health');memory=get('8730/v1/runtime/memory')
assert cfg['runtime']['builtin_revision']==52 and cfg['model']['default_model']=='qwen38fn_exl3'
assert runtime['selected_bundle']=='qwen38fn_exl3' and runtime['operation']['state']=='complete'
assert health['video']['steps']==4 and not memory['busy'] and not memory['quiescing']
events=json.loads((private/'sample-events.json').read_text())
totals=sorted({x['data']['progress']['total'] for x in events if x['event']=='tool_output' and x['data'].get('progress',{}).get('total') is not None})
assert totals==[4]
assert not any(x['event']=='error' for x in events)
final_performance=next(x['data'] for x in reversed(events) if x['event']=='performance')
evidence=[x for x in events if x['event'] in ['tool_start','tool_output','tool_result','media_attached','done','error']]
evidence.append({'event':'performance','data':final_performance})
(private/'sample-evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2))
raw=subprocess.check_output(['docker','exec','sparktalk-qwim-mmh3','cat','/job/events.jsonl']).decode()
all_native=[json.loads(x) for x in raw.splitlines()]
case=next(x['case'] for x in reversed(all_native) if x['event']=='idle')
native=[x for x in all_native if x['case']==case]
adapter=next(x['acceleration']['pdmd'] for x in native if x['event']=='attention_complete')
assert adapter['called_modules']==208 and adapter['base_weights_unchanged']
(private/'sample-native.json').write_text(json.dumps(native,indent=2))
hist=json.loads(subprocess.check_output(['docker','exec','sparktalk-qwim-mmh3','cat','/state/timings.json']))
new_profiles={k:v for k,v in hist.items() if k.endswith('pdmd4-v6')}
assert 'h3-t2v-864x480-124-24-pdmd4-v6' in new_profiles
sample=json.loads((private/'sample-result.json').read_text())
media=json.loads((private/'sample-media.json').read_text())
asr=json.loads((private/'sample-asr.json').read_text())
assert sample['identical_to_qualified_sample'] and asr['text']=='안녕하세요. 좋은 하루 보내세요.'
sessions=get('8585/api/sessions')
assert [s['id'] for s in sessions if s['title']==sample['title']]==[sample['session_id']]

def compose(path):
    return json.loads(subprocess.check_output(['docker','compose','-f',str(path),'config','--format','json']))['services']['runtime']
standalone=compose(repo/'compose_yaml/qwim_mmh3_service/compose.yaml')
embedded=compose(Path('/home/edp1096/.local/share/sparktalk/runtime/qwim-mmh3/compose.yaml'))
equal_fields=['image','container_name','mem_limit','memswap_limit','restart','stop_grace_period','network_mode','ipc']
for k in equal_fields:assert standalone.get(k)==embedded.get(k),k
injected={k:v for k,v in embedded['environment'].items() if k not in standalone['environment']}
assert injected=={'SPARKTALK_KEEP_MODELS_LOADED':'1'}
assert standalone['environment']=={k:v for k,v in embedded['environment'].items() if k not in injected}
assert standalone['build']['context']!=embedded['build']['context']
image=json.loads((private/'image.json').read_text())
paths=['worker.py','pdmd_lora.py','prepare_models.py','api.py','generation_progress.py','Dockerfile','runtime-requirements.txt']
source_hashes={}
for f in paths:
    src=repo/'compose_yaml/qwim_mmh3_service'/f
    embedded_src=repo/'util/talk/internal/orchestrator/assets/qwim-mmh3'/f
    assert src.read_bytes()==embedded_src.read_bytes(),f
    source_hashes[f]=hashlib.sha256(src.read_bytes()).hexdigest()
report={
 'status':'deployed-and-verified', 'finished_utc':datetime.now(timezone.utc).isoformat(),
 'host':'61 only; host 60 untouched',
 'default':'PDMD 4NFE v6, BF16 residual over NVFP4, Euler, dense attention, video/audio shifts 12/3, strength 1.0',
 'image':image,'health':health,'runtime_memory':memory,'adapter_verified_after_generation':adapter,
 'inference_versions':{'torch':'2.13.0a0+9186a08b2c.nv26.7.59513937','transformers':'5.18.0','huggingface_hub':'1.33.0','comfy-kitchen':'0.2.37','comfy-aimdo':'0.5.5','av':'19.0.1','numpy':'2.1.0','safetensors':'0.8.0','tokenizers':'0.23.1'},
 'configuration':{'builtin_revision':52,'selected_bundle':runtime['selected_bundle'],'component_budget_gib':30,'startup_gib':20,'workspace_gib':6,'cgroup_gib':40,'standalone_and_talk_runtime_fields_equal':equal_fields,'recipe_environment_equal':True,'talk_injected_environment':injected,'separate_build_contexts':True,'no_workspace_runtime_bind_mount':True,'source_sha256':source_hashes},
 'checks':{'go':'internal/config, internal/orchestrator, internal/server passed','python':'14 API/progress/image-input tests passed','packaged_assets':'113 support assets verified; all four recipe checks passed','git_diff_check':'passed','progress_totals':totals,'new_eta_profiles':new_profiles},
 'production_i2v':{'native_seconds':json.loads((private/'production-i2v.json').read_text())['native_seconds'],'fidelity':json.loads((private/'pixel-comparison.json').read_text()),'frame0_encoded':True,'all_208_adapter_modules_executed':True},
 'talk_sample':{**sample,'media':media,'asr':asr,'native_generation_seconds':next(x['seconds'] for x in native if x['event']=='idle'),'whole_talk_turn_seconds':final_performance['elapsed_seconds'],'progress_saved':True},
 'quality_scope':'One final Korean speech sample and one I2V reproduction. Both match qualified experimental output exactly. This does not establish universal speech/lip-sync quality. A preceding free-form Talk prompt had a one-syllable ASR mismatch; that trial conversation was removed after the final sample was verified. The final sample uses the qualified prompt unchanged.',
 'sources':['https://huggingface.co/Iwannapose/minimax_h3_pdmd_4nfe_comfyui/tree/ae6ab62d28754b9ce052798b92d9567161568f28','https://huggingface.co/pdmd2026/pdmd_4NFE_lora', 'util/talk/docs/h3-pdmd-comparison-20261022.json'],
}
for filename,source in [('go-tests.log',Path('/tmp/h3-pdmd-go-final.log')),('python-tests.log',Path('/tmp/h3-pdmd-python-tests.log'))]:
    shutil.copy2(source,private/filename)
name='h3-pdmd-deployment-20261022'
archive=docs/(name+'.tar.gz')
allowed=['validate_api.py','talk_sample.py','package_deployment.py','image.json','production-i2v.json','pixel-comparison.json','sample-result.json','sample-media.json','sample-asr.json','sample-evidence.json','sample-native.json','go-tests.log','python-tests.log']
with tarfile.open(archive,'w:gz') as t:
    for f in allowed:t.add(private/f,arcname=f)
report['archive']={'path':str(archive.relative_to(repo)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size}
(docs/(name+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
gallery=docs/'h3-pdmd-comparison-20261022'
shutil.copy2(private/'talk-sample.mp4',gallery/'media/talk-pdmd4-sample.mp4')
shutil.copy2(private/'talk-sample.jpg',gallery/'frames/talk-pdmd4-sample.jpg')
page=gallery/'index.html';text=page.read_text().replace('현재 Talk는 기존 20스텝으로 복구했습니다.','Talk에 PDMD 4스텝 적용을 완료했습니다. 최종 대화방: PDMD4 적용 샘플 · 한국어 영상.')
tag='<section><h2>실제 Talk 최종 샘플</h2><p>한국어 대사 ASR 일치 · 검증 샘플과 파일 해시 일치 · 864×480 / 124프레임 / 음성 포함</p><video controls preload="metadata" src="media/talk-pdmd4-sample.mp4" style="max-width:864px"></video><p><a href="../h3-pdmd-deployment-20261022.json">적용·확인 기록</a></p></section>'
text=text.replace('<section><h2>텍스트 → 영상: 고양이</h2>',tag+'<section><h2>텍스트 → 영상: 고양이</h2>',1)
# Playback controls apply only to the three comparison rows.
text=text.replace("document.querySelectorAll('section').forEach", "document.querySelectorAll('section:has(.play)').forEach")
page.write_text(text)
print(json.dumps({'report':str(docs/(name+'.json')),'sample':sample,'native_seconds':report['talk_sample']['native_generation_seconds'],'talk_seconds':report['talk_sample']['whole_talk_turn_seconds']},ensure_ascii=False,indent=2))
