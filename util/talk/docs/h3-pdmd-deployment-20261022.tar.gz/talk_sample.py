import json
import time
import urllib.request
from pathlib import Path

root=Path('/home/edp1096/.cache/sparktalk/experiments/h3-pdmd/deployment')
base='http://127.0.0.1:8585'
title='PDMD4 적용 샘플 · 한국어 영상'
def call(path,body=None,method=None):
    data=None if body is None else json.dumps(body).encode()
    req=urllib.request.Request(base+path,data=data,method=method,headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=300) as r:return json.load(r)

session=call('/api/sessions',{'title':title,'reasoning_effort':'medium'})
sid=session['id']
(root/'sample-session.json').write_text(json.dumps(session,ensure_ascii=False,indent=2))
print('SESSION',sid,flush=True)
prompt=next(x['prompt'] for x in json.loads((root.parent/'cases.json').read_text()) if x['case']=='pdmd4-speech-ko')
body={'session_id':sid,'reasoning_effort':'medium','tools_enabled':True,
      'content':'한국어 발화 영상 샘플을 만들어 줘. 시드는 99를 사용하고, 아래 영상 설명을 그대로 사용해 줘:\n\n'+prompt}
req=urllib.request.Request(base+'/api/chat',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'})
events=[];kind=None;start=time.monotonic()
with urllib.request.urlopen(req,timeout=360) as response:
    for raw in response:
        line=raw.decode().rstrip('\r\n')
        if line.startswith('event: '):kind=line[7:]
        elif line.startswith('data: '):
            data=json.loads(line[6:]);events.append({'event':kind,'data':data})
            if kind in ['error','done','media_attached','tool_start','tool_result']:
                print('EVENT',kind,json.dumps(data,ensure_ascii=False)[:250],flush=True)
(root/'sample-events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2))
assert any(e['event']=='done' for e in events),[e for e in events if e['event']=='error']
messages=call('/api/sessions/'+sid+'/messages')
(root/'sample-messages.json').write_text(json.dumps(messages,ensure_ascii=False,indent=2))
attachments=[a for m in messages for a in (m.get('attachments') or []) if a.get('mime')=='video/mp4']
assert len(attachments)==1,attachments
time.sleep(3)
call('/api/sessions/'+sid,{'title':title},'PATCH')
result={'session_id':sid,'title':title,'seconds':time.monotonic()-start,'attachment':attachments[0]}
(root/'sample-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print('RESULT',json.dumps(result,ensure_ascii=False),flush=True)
