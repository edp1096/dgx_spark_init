import base64
import json
import re
import subprocess
import threading
import time
import urllib.request
from pathlib import Path

root=Path('/home/edp1096/.cache/sparktalk/experiments/h3-pdmd')
out=root/'deployment'
url='http://127.0.0.1:8730'
for _ in range(300):
    try:
        health=json.load(urllib.request.urlopen(url+'/health',timeout=3))
        if health.get('video',{}).get('steps')==4 and health['acceleration']['pdmd']['modules']==208:
            break
    except Exception:pass
    time.sleep(2)
else:raise RuntimeError('PDMD production health timeout')
print('PDMD4 ready',flush=True)
case=json.loads((root/'i2v-cases.json').read_text())[1]
body={'prompt':case['prompt'],'seed':case['seed'],'first_frame':'data:image/png;base64,'+base64.b64encode((root/'review/cat-input.png').read_bytes()).decode()}
request_id='d4'*16
events=[];done=threading.Event()
def progress():
    cursor=0
    while not done.wait(1):
        try:
            d=json.load(urllib.request.urlopen(url+'/v1/runtime/progress/'+request_id+'?after='+str(cursor),timeout=3))
            events.extend(d['events']);cursor=d['next']
        except Exception:pass
thread=threading.Thread(target=progress);thread.start()
start=time.monotonic()
try:
    req=urllib.request.Request(url+'/v1/videos/generations',data=json.dumps(body).encode(),headers={'Content-Type':'application/json','X-SparkTalk-Request-ID':request_id})
    with urllib.request.urlopen(req,timeout=240) as response:
        data=response.read();headers={k.lower():v for k,v in response.headers.items()}
finally:
    done.set();thread.join()
seconds=time.monotonic()-start
(out/'production-i2v.mp4').write_bytes(data)
total_steps={e['total'] for e in events if e.get('event')=='progress'}
assert total_steps=={4}, total_steps
assert headers['x-video-input-mode']=='i2v' and headers['x-video-width']=='864' and headers['x-video-height']=='480',headers
disposition=next(v for k,v in headers.items() if k.lower()=='content-disposition')
native_case=re.search(r'MiniMax-H3-([a-f0-9]+)\.mp4',disposition).group(1)
raw=subprocess.check_output(['docker','exec','sparktalk-qwim-mmh3','cat','/job/events.jsonl']).decode()
native=[json.loads(x) for x in raw.splitlines() if json.loads(x).get('case')==native_case]
acceleration=next(e['acceleration'] for e in native if e['event']=='attention_complete')
assert acceleration['steps']==4 and acceleration['pdmd']['called_modules']==208
result={'seconds':seconds,'bytes':len(data),'request_id':request_id,'health':health,'headers':headers,'progress':events,'native':native}
(out/'production-i2v.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'seconds':seconds,'bytes':len(data),'progress_total':sorted(total_steps),'called_modules':208}),flush=True)
