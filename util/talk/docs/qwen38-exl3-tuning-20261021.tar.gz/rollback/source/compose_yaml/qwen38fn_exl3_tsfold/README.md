# Qwen 3.8 Flash-Next EXL3 3bit · TensorFold

Python CUDA · TP1 · Q8 KV · YaRN 4 / 1M · MTP 3 with a Korean-expanded draft vocabulary · 1 cached inference prefix.

```sh
docker compose up -d --build
docker compose logs -f runtime
```

Uses the existing Huihui checkpoint read-only. This directory owns its standalone Compose and build context. Talk maintains separate embedded files and materializes them in its own runtime directory; neither build nor startup copies files from this directory. The model set ID and endpoint stay unchanged. Images, tools, streaming and Thinking off/Medium are validated before promotion. EXL3 vision is decoded once into a hashed runtime cache using TensorFold's upstream converter; source weights remain unchanged.

Source: [TensorFold](https://github.com/ashhart/TensorFold/tree/db281878ddb836fd0df510d8771ecb7e0fe47d26), [recipe](https://github.com/ashhart/TensorFold/tree/db281878ddb836fd0df510d8771ecb7e0fe47d26), [local qualification](../../util/talk/docs/qwen38-tensorfold-promotion-20261020.json).
