from pathlib import Path
import argparse,json,subprocess,time,sys,fcntl
j=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('--depth',default='3');p.add_argument('--confidence',default='0');p.add_argument('--vocab',default='current');p.add_argument('--suite',default='screen');p.add_argument('--tuning',default='none');a=p.parse_args();name='qwen-exl3-tuning'
lock=(j/'launch.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX)
for attempt in range(60):
 if subprocess.run(['docker','inspect',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:break
 time.sleep(1)
else:raise RuntimeError('Previous trial container did not exit')
cmd=['docker','run','--rm','--name',name,'--gpus','all','--ipc','host','--cpuset-cpus','5-9,15-19','--memory','112g','--memory-swap','112g','--entrypoint','python3','-e','PYTHONUNBUFFERED=1','-e','HF_HUB_OFFLINE=1','-e','TRANSFORMERS_OFFLINE=1','-e','TENSORFOLD_NO_UPDATE_CHECK=1','-e','TENSORFOLD_MEMORY_RESERVE_GIB=4','-e','OMP_NUM_THREADS=4','-e','TORCH_EXTENSIONS_DIR=/job/runtime/torch-extensions','-e','TRITON_CACHE_DIR=/job/runtime/triton','-e','MAX_JOBS=1','-e','TORCH_CUDA_ARCH_LIST=12.1','-e','PYTHONPATH=/opt/tensorfold/src','-v',str(j)+':/job','-v',str(j/'engine')+':/opt/tensorfold:ro','-v','/home/edp1096/.cache/model-download-jobs/qwen38-exl3-tensorfold-20261020/model:/model:ro','-v','/home/edp1096/.cache/huggingface:/home/edp1096/.cache/huggingface:ro','-v','/home/edp1096/.local/share/sparktalk/cache/qwen38-exl3-tensorfold:/prod-runtime:ro','local/sparktalk-qwen38-exl3-tensorfold:db281878-vision2','/job/run-arm.py',a.label,'--depth',a.depth,'--confidence',a.confidence,'--vocab',a.vocab,'--suite',a.suite,'--tuning',a.tuning]
(j/(a.label+'-command.json')).write_text(json.dumps(cmd,indent=2));print('LAUNCH',a.label,flush=True)
with (j/(a.label+'.log')).open('w') as log:
 proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT);start=time.monotonic()
 try:
  while proc.poll() is None:
   mem={x.split(':')[0]:int(x.split()[1])*1024 for x in Path('/proc/meminfo').read_text().splitlines()}
   if mem['MemAvailable']<2*1024**3:raise RuntimeError('System memory floor reached')
   if time.monotonic()-start>1200:raise TimeoutError('Arm deadline')
   time.sleep(.5)
  if proc.returncode:raise RuntimeError(f'Arm exited {proc.returncode}; inspect retained log')
  print('ARM_DONE',a.label,flush=True)
 except BaseException:
  subprocess.run(['docker','stop','--time','5',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);proc.wait(timeout=30);raise
