import json
import numpy as np
import torch

def run(out):
 from tensorfold.cuda.exl3 import experts
 rng=np.random.default_rng(713);slots=11;E=513;checks=[]
 for R in [128,129,511,512,1023,1024,2047,2048]:
  raw=rng.integers(0,E+4,size=(R,slots),dtype=np.int32)
  pick=torch.from_numpy(raw).cuda();ids=torch.empty(E,device='cuda',dtype=torch.int32);count=torch.empty(1,device='cuda',dtype=torch.int32);members=torch.full((E,R),777,device='cuda',dtype=torch.int32)
  experts._ext().group(pick,ids,count,members,R,slots,E)
  got=members.cpu().numpy();actual_ids=ids.cpu().numpy();actual_count=count.item()
  assert actual_count==E and np.array_equal(actual_ids,np.arange(E))
  for e in range(E):
   index=np.flatnonzero(raw.ravel()==e)[:R];expected=(index//slots)*32+(index%slots)
   assert np.array_equal(got[e,:len(expected)],expected),(R,e)
   assert np.all(got[e,len(expected):]==-1),(R,e,'tail')
  checks.append({'rows':R,'slots':slots,'experts':E,'passed':True})
  del pick,ids,count,members
 (out/'grouping-verification.json').write_text(json.dumps({'passed':True,'reference':'Independent NumPy stable membership including ignored out-of-range experts','checks':checks},indent=2))
 print('GROUPING_REFERENCE_PASSED',len(checks),flush=True)
