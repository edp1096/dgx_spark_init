import json,hashlib,collections,re
from pathlib import Path
from tokenizers import Tokenizer
from tensorfold.cuda.chat_template import ChatTemplate
j=Path('/job');m=Path('/model');tok=Tokenizer.from_file(str(m/'tokenizer.json'));template=ChatTemplate(m)
v=tok.get_vocab_size();stock=[int(x) for x in (j/'engine/src/tensorfold/families/qwen4_exp/cuda/draft_vocab.txt').read_text().split()]
text=[tok.decode([i],skip_special_tokens=False) for i in range(v)]
hangul={i for i,t in enumerate(text) if any('\uac00'<=c<='\ud7a3' for c in t)}
base=set(stock)|hangul;assert len(base)==86218,len(base)
raw=json.loads((m/'tokenizer.json').read_text());special={x['id'] for x in raw.get('added_tokens',[])}
protected=hangul|special|set(range(256))
freq=collections.Counter();calibration=[]
for p in sorted((j/'engine/src/tensorfold/families/qwen4_exp/cuda').glob('*.py')):
 s=p.read_text()[:65536];freq.update(tok.encode(s,add_special_tokens=False).ids);calibration.append({'path':str(p.relative_to(j/'engine')),'sha256':hashlib.sha256(s.encode()).hexdigest()})
extra='''When the user requests recent information, use the available tools and check the source. Explain the result clearly in Korean. We need to compare the alternatives, verify the calculation, inspect the data, handle errors, and finish the requested work. A transaction commits only after every operation succeeds. The function returns a JSON object containing status, query, source, title, date, and results. 한국어와 영어 문장, 프로그래밍 코드, 함수 인자와 JSON 문자열을 정확하게 처리합니다. 먼저 조건을 확인하고 계산 결과를 검증합니다. 검색 결과의 제목과 주소를 확인한 뒤 근거에 따라 답변합니다.'''
freq.update(tok.encode(extra,add_special_tokens=False).ids)
english={i for i,t in enumerate(text) if t and t.isascii() and any(c.isalpha() for c in t)}
key=lambda i:(-freq[i],i)
short=set(protected);short.update(sorted(base-protected,key=key)[:65536-len(short)]);assert len(short)==65536
sets={'current':base,'mix64':short}
seed=base|short
for name,n in [('mix96',98304),('mix128',131072)]:
 ids=set(seed)
 for pool in [set(freq),english,set(range(v))]:
  take=sorted(pool-ids,key=key)[:n-len(ids)];ids.update(take)
  if len(ids)==n:break
 assert len(ids)==n
 sets[name]=ids;seed=ids
out=j/'vocabs';out.mkdir(exist_ok=True);meta={}
for name,ids in sets.items():
 ordered=sorted(ids);data=''.join(f'{i}\n' for i in ordered);(out/(name+'.txt')).write_text(data)
 assert protected<=ids,name
 meta[name]={'size':len(ids),'sha256':hashlib.sha256(data.encode()).hexdigest(),'english_ascii_tokens':len(ids&english),'protected_tokens':len(protected)}
meta['tokenizer_sha256']=hashlib.sha256((m/'tokenizer.json').read_bytes()).hexdigest();meta['calibration']=calibration;meta['policy']='MTP head only. Preserve Hangul, byte and added tokens. Rank using independent engine source and a fixed bilingual paragraph; no evaluation generations. Expanded sets retain the current shortlist.'
(out/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
questions=[('ko','데이터베이스 트랜잭션 격리 수준 네 가지를 한국어로 자세히 설명하고, 각 수준에서 발생할 수 있는 동시성 문제를 실제 사례 세 가지씩 들어 비교해 주세요. 충분한 분량으로 설명해 주세요.'),('reason','Solve the following planning problem carefully, reason in English when useful, and give the final explanation in Korean. Six independent tasks take 2, 3, 5, 7, 11 and 13 minutes. Two workers can each do one task at a time, and a task cannot be interrupted. Find an optimal schedule, prove its optimality, and discuss how to generalize the method.'),('code','Python으로 TTL과 LRU 정책을 지원하는 스레드 안전 캐시를 구현해 주세요. 타입 힌트, 만료 항목 회수, 크기 제한, 잠금과 경계 조건을 포함하고 사용 예제와 설계 설명도 자세히 써 주세요.'),('mixed','Explain a reliable web-search workflow for an assistant. Include function-call JSON examples, result validation, retries, dates and source URLs. Then explain the same workflow fully in Korean with a Python example. Do not perform a real web search; this is a software design example.')]
cases=[]
def item(name,mode,messages,n,kind='tg',temperature=.7,stop=False,tools=None):
 s=template.render(messages,tools=tools,enable_thinking=mode=='medium',extra={'reasoning_effort':'medium'} if mode=='medium' else {})
 ids=tok.encode(s,add_special_tokens=False).ids
 return {'name':name,'mode':mode,'messages':messages,'tools':tools,'input_ids':ids,'input_sha256':hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest(),'max_tokens':n,'kind':kind,'temperature':temperature,'stop_eos':stop}
for mode in ['off','medium']:
 for label,q in questions:cases.append(item(label+'-'+mode,mode,[{'role':'user','content':q}],256))
 for label,q in questions[:2]:cases.append(item('greedy-'+label+'-'+mode,mode,[{'role':'user','content':q}],256,temperature=0))
quality=[]
for mode in ['off','medium']:
 quality.append(item('math-'+mode,mode,[{'role':'user','content':'17 곱하기 23의 결과를 구하고 마지막 답은 숫자만 출력하세요.'}],768,'quality',stop=True))
 quality.append(item('json-'+mode,mode,[{'role':'user','content':'설명 없이 JSON 하나만 출력하세요. name은 Seoul, count는 정수 3, enabled는 참입니다.'}],768,'quality',stop=True))
(j/'cases.json').write_text(json.dumps(cases,ensure_ascii=False));(j/'quality-cases.json').write_text(json.dumps(quality,ensure_ascii=False));print('PREPARED',json.dumps({k:x for k,x in meta.items() if k in sets}),len(cases),flush=True)
