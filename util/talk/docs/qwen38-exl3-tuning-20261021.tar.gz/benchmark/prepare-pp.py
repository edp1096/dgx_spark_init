import json,hashlib
from pathlib import Path
from tokenizers import Tokenizer
from tensorfold.cuda.chat_template import ChatTemplate
j=Path('/job');t=Tokenizer.from_file('/model/tokenizer.json');chat=ChatTemplate(Path('/model'))
rendered=chat.render([{'role':'user','content':'Read the reference document and answer the final question.\n__DOCUMENT__\nFinal question: What is the difference between a transaction commit and rollback? Answer briefly in Korean.'}],tools=None,enable_thinking=False)
a,b=rendered.split('__DOCUMENT__');prefix=t.encode(a,add_special_tokens=False).ids;suffix=t.encode(b,add_special_tokens=False).ids
paragraph='Reference section: A transaction groups a sequence of database operations. Commit makes the completed changes permanent. Rollback cancels the pending changes and restores the previous valid state. Isolation controls what concurrent transactions can observe. Recovery uses logs and consistency checks.\n'
body=t.encode(paragraph*5000,add_special_tokens=False).ids;cases=[]
for n in [4096,16384,65536,131072]:
 ids=prefix+body[:n-len(prefix)-len(suffix)]+suffix;assert len(ids)==n
 cases.append({'name':f'pp-{n}','mode':'off','kind':'pp','temperature':.7,'input_ids':ids,'input_sha256':hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest(),'max_tokens':16,'stop_eos':False})
(j/'pp-cases.json').write_text(json.dumps(cases));print('PP_CASES_READY',flush=True)
