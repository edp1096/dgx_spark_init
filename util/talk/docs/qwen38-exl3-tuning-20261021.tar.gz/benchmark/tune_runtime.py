import numpy as np,torch

def apply(kind):
 if kind=='sample':
  import tensorfold.cuda.sampling as common
  import tensorfold.families.qwen4_exp.cuda.decode as dec
  original_common=common.sample_rows
  def sample_rows(logits,positions,sampling):
   if sampling is None or sampling.temperature<=0 or not sampling.top_k:return original_common(logits,positions,sampling)
   if logits.ndim!=2 or not logits.is_cuda or len(positions)!=logits.shape[0]:raise ValueError('invalid sampling rows')
   count=min(logits.shape[1],int(sampling.top_k)+common.MARGIN)
   if count==logits.shape[1]:return original_common(logits,positions,sampling)
   vals,idx=torch.topk(logits.float(),count,dim=-1,sorted=False)
   packed=torch.cat((vals,idx.to(torch.int32).view(torch.float32)),dim=1).cpu().numpy()
   return common.choose_rows(packed[:,:count],np.ascontiguousarray(packed[:,count:]).view(np.int32).astype(np.int64),positions,sampling)
  original_mapped=dec.sample_mapped
  def sample_mapped(logits,positions,sampling,id_map):
   if sampling is None or sampling.temperature<=0:return original_mapped(logits,positions,sampling,id_map)
   count=min(logits.shape[1],int(sampling.top_k)+common.MARGIN) if sampling.top_k else logits.shape[1]
   vals,idx=torch.topk(logits.float(),count,dim=-1,sorted=False)
   ids=id_map[idx].to(torch.int32)
   packed=torch.cat((vals,ids.view(torch.float32)),dim=1).cpu().numpy()
   return common.choose_rows(packed[:,:count],np.ascontiguousarray(packed[:,count:]).view(np.int32).astype(np.int64),positions,sampling)
  common.sample_rows=sample_rows;dec.sample_rows=sample_rows;dec.sample_mapped=sample_mapped
 elif kind in ['compact','compact2k','parallel2k']:
  from compact_experts import install
  install()
  if kind in ['compact2k','parallel2k']:
   from tensorfold.families.qwen4_exp.cuda import exl3_pack,exl3_mm
   exl3_pack.MOE_WINDOW=exl3_mm.MOE_WINDOW=2048
  if kind=='parallel2k':
   from parallel_group import install as install_group
   install_group()
 elif kind=='window2k':
  from tensorfold.families.qwen4_exp.cuda import exl3_pack,exl3_mm
  exl3_pack.MOE_WINDOW=exl3_mm.MOE_WINDOW=2048
 else:raise ValueError(kind)
