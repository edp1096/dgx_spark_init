import json,hashlib
from pathlib import Path
from tokenizers import Tokenizer
from tensorfold.cuda.chat_template import ChatTemplate
j=Path('/job');tok=Tokenizer.from_file('/model/tokenizer.json');t=ChatTemplate(Path('/model'))
questions=[('ko','사과 과수원의 봄철 서리 피해를 줄이는 방법을 지형, 관수, 방풍 및 예보 활용으로 나누어 원리와 한계를 한국어로 설명해 주세요.'),('reason','A rectangle has integer side lengths and perimeter 100. Count the unordered side pairs whose area is divisible by 12, verify your answer by enumerating the possibilities, and explain in Korean.'),('code','Write a Python incremental UTF-8 line parser for arbitrarily split byte chunks. Include error handling, finalization and examples. Explain design choices in Korean.'),('mixed','Design a bilingual meeting scheduling protocol between Seoul and Paris that handles daylight saving changes, conflicting availability, calendar revisions and duplicate requests. Give detailed JSON examples and Korean explanations.')]
cases=[]
for mode in ['off','medium']:
 for name,q in questions:
  ids=tok.encode(t.render([{'role':'user','content':q}],tools=None,enable_thinking=mode=='medium',extra={'reasoning_effort':'medium'} if mode=='medium' else {}),add_special_tokens=False).ids
  cases.append({'name':'holdout-'+name+'-'+mode,'mode':mode,'kind':'tg','temperature':.7,'seed':99,'max_tokens':512,'stop_eos':False,'input_ids':ids,'input_sha256':hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest()})
(j/'holdout-cases.json').write_text(json.dumps(cases,ensure_ascii=False));print('HOLDOUT_PREPARED',len(cases))
