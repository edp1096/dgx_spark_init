import argparse,os,json,time,hashlib,statistics,threading,sys
from pathlib import Path
import torch
from tokenizers import Tokenizer
from tensorfold.engine.exact_sampling import Sampling
from tensorfold.families.qwen4_exp.cuda import engine as engine_module
from tensorfold.families.qwen4_exp.cuda.engine import FlashNextEngine
from tensorfold.families.qwen4_exp.cuda.graphs import Graphs
j=Path('/job');p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('--depth',type=int,default=3);p.add_argument('--confidence',type=float,default=0.0);p.add_argument('--vocab',default='current');p.add_argument('--suite',default='screen');p.add_argument('--tuning',default='none');a=p.parse_args();out=j/'results'/a.label;out.mkdir(parents=True,exist_ok=False)
engine_module.KEEP=1;os.environ['TENSORFOLD_VISION_WEIGHTS']='/prod-runtime/exl3-vision-f16.safetensors'
metrics={'count':0,'seconds':0.};original=Graphs._capture

def capture(self,fn):
 t=time.perf_counter();r=original(self,fn);metrics['count']+=1;metrics['seconds']+=time.perf_counter()-t;return r
Graphs._capture=capture
settings={'depth':a.depth,'confidence':a.confidence,'vocab':a.vocab,'context':1048576,'kv':'int8','streams':2,'vision':True,'kept_prefixes':1,'torch':torch.__version__,'gpu':torch.cuda.get_device_name(0),'suite':a.suite,'tuning':a.tuning}
settings['source_sha256']={name:hashlib.sha256((j/name).read_bytes()).hexdigest() for name in ['run-arm.py','tune_runtime.py','compact_experts.py','parallel_group.py']}
(out/'settings.json').write_text(json.dumps(settings,indent=2));print('ARM_START',a.label,json.dumps(settings),flush=True)
if a.tuning!='none':
 from tune_runtime import apply
 apply(a.tuning)
t0=time.perf_counter()
sys.path.insert(0,'/job/recipe')
from launch import prepare_runtime
model_view=prepare_runtime(Path('/model'),j/'runtime',1048576)
e=FlashNextEngine(model_view,depth=a.depth,confidence=a.confidence,draft_vocab=str(j/'vocabs'/(a.vocab+'.txt')),max_len=1048576,context_explicit=True,kv_dtype='int8',streams=2,graphs=True,vision=True,prefetch=False)
for table in {id(layer.ple.table):layer.ple.table for layer in e.w.layers if layer.ple is not None}.values():table.prefetch()
tok=Tokenizer.from_file('/model/tokenizer.json');print('ENGINE_READY',a.label,'startup_s',time.perf_counter()-t0,flush=True)
(out/'capacity.json').write_text(json.dumps(e.capacity_plan,indent=2))
def clear():
 assert not e.multi.streams and not e.multi.filling
 states={id(k[1]):k[1] for k in e.multi.kept}
 e.multi.kept.clear();e.multi.passed.clear()
 for st in states.values():
  if all(f is not st for f in e.multi.free):e.multi.free.append(st)
 if e.multi.solo is not None:
  preferred=e.multi.solo.st
  if any(f is preferred for f in e.multi.free):e.multi.free=[f for f in e.multi.free if f is not preferred]+[preferred]
def generate(case,count=None,draft=True,keep=False):
 if not keep:clear()
 ids=[];seed=Sampling(seed=case.get('seed',42),temperature=case['temperature'],top_k=20,top_p=.95)
 before=dict(metrics);t=time.perf_counter()
 s=e.generate(case['input_ids'],count or case['max_tokens'],seed,lambda new:ids.extend(new),draft=draft,stop_eos=case.get('stop_eos',False))
 wall=time.perf_counter()-t;n=len(ids);prefill=s.get('prefill_s',0);decode=s.get('decode_s',0)
 row={'name':case['name'],'mode':case['mode'],'kind':case['kind'],'temperature':case['temperature'],'input_tokens':len(case['input_ids']),'input_sha256':case['input_sha256'],'output_tokens':n,'output_ids':ids,'output_sha256':hashlib.sha256(json.dumps(ids,separators=(',',':')).encode()).hexdigest(),'text':tok.decode(ids,skip_special_tokens=False),'stats':s,'wall_s':wall,'pp':(len(case['input_ids'])-s.get('cached',0))/prefill if prefill else None,'tg':(n-1)/decode if decode and n>1 else None,'graph_captures':metrics['count']-before['count'],'graph_capture_s':metrics['seconds']-before['seconds']}
 return row
def profile_prefill(e,case,out,clear):
 from tensorfold.cuda.streams import Stream
 e.scheduler.close();e.scheduler=None
 clear()
 st=Stream(case['input_ids'],1,Sampling(seed=42,temperature=.7,top_k=20,top_p=.95),draft=True,stop_eos=False)
 with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA]) as prof:
  e.multi.admit(st)
  while e.multi.live():
   done=e.multi.round();e.multi.finish(done)
  torch.cuda.synchronize()
 prof.export_chrome_trace(str(out/'prefill-trace.json'))
 stats=[]
 for ev in prof.key_averages():
  stats.append({'key':ev.key,'count':ev.count,'self_gpu_us':getattr(ev,'self_device_time_total',0),'cpu_us':ev.self_cpu_time_total})
 (out/'prefill-profile.json').write_text(json.dumps(sorted(stats,key=lambda r:r['self_gpu_us'],reverse=True),indent=2))
rows=[]
try:
 cases=json.loads((j/('pp-cases.json' if a.suite in ['pp','pp-fast'] else 'holdout-cases.json' if a.suite in ['holdout','holdout-qualify'] else 'cases.json')).read_text())
 if a.suite=='micro':cases=cases[:2]
 if a.suite=='pp-fast':cases=cases[:2]
 if a.suite in ['pp','pp-fast']:cases += [{**c,'name':c['name']+'-repeat'} for c in cases[:2]]
 # Grow solo state to fit all short requests and warm the chosen draft widths.
 for c in ([cases[0]] if a.suite in ['pp','pp-fast','micro'] else [cases[0],cases[4]] if a.suite in ['holdout','holdout-qualify'] else [cases[0],cases[6]]):generate(c,16 if a.suite in ['pp','pp-fast'] else 768)
 (out/'warmup-graphs.json').write_text(json.dumps(metrics,indent=2))
 for c in cases:
  r=generate(c);rows.append(r);(out/(c['name']+'.json')).write_text(json.dumps(r,ensure_ascii=False,indent=2));(out/'results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));s=r['stats'];assert s['cached']==0,(c['name'],s)
  assert s.get('accepted',0)<=s.get('drafted',0)
  print(json.dumps({'arm':a.label,'name':r['name'],'tg':r['tg'],'pp':r['pp'],'accepted':s.get('accepted'),'drafted':s.get('drafted'),'rounds':s.get('rounds'),'captures':r['graph_captures']}),flush=True)
 summary={}
 for mode in ['off','medium']:
  group=[r for r in rows if r['mode']==mode and r['temperature']==.7]
  if not group:continue
  summary[mode]={'weighted_tg':sum(r['output_tokens']-1 for r in group)/sum(r['stats']['decode_s'] for r in group),'mean_tg':statistics.mean(r['tg'] for r in group),'accepted':sum(r['stats'].get('accepted',0) for r in group),'drafted':sum(r['stats'].get('drafted',0) for r in group),'captures':sum(r['graph_captures'] for r in group)}
 (out/'summary.json').write_text(json.dumps(summary,indent=2));print('ARM_SUMMARY',a.label,json.dumps(summary),flush=True)
 if a.suite in ['baseline','qualify','holdout-qualify']:
  checks=[]
  for c in ([cases[0],cases[2],cases[4],cases[6]] if a.suite=='holdout-qualify' else [cases[0],cases[4],cases[8],cases[10]]):
   serial=generate(c,128,draft=False);draft=generate(c,128,draft=True);cached=generate(c,128,draft=True,keep=True)
   check={'name':c['name'],'serial_draft_equal':serial['output_ids']==draft['output_ids'],'cached_equal':draft['output_ids']==cached['output_ids'],'cached_tokens':cached['stats']['cached']};checks.append(check);(out/'exactness.json').write_text(json.dumps(checks,indent=2));assert check['serial_draft_equal'] and check['cached_equal'],check
  quality=[]
  for c in json.loads((j/'quality-cases.json').read_text()):quality.append(generate(c))
  (out/'quality.json').write_text(json.dumps(quality,ensure_ascii=False,indent=2))
 if a.suite=='holdout-qualify' and a.tuning=='parallel2k':
  from verify_grouping import run as verify_grouping
  verify_grouping(out)
 if a.suite=='micro':
  from profile_kernels import run
  run(e,out)
 if a.suite=='pp':
  profile_prefill(e,cases[0],out,clear)
 (out/'COMPLETE').write_text(time.strftime('%FT%T%z'));print('ARM_COMPLETE',a.label,flush=True)
finally:e.close()
