"""Local ASR check of the generated Korean speech; no user conversations."""
import json
import re
import time
import urllib.request
from pathlib import Path

root = Path('/home/edp1096/.cache/sparktalk/experiments/h3-pdmd')
reference = '안녕하세요. 좋은 하루 보내세요.'

def distance(a,b):
    row=list(range(len(b)+1))
    for i,x in enumerate(a,1):
        new=[i]
        for j,y in enumerate(b,1): new.append(min(new[-1]+1,row[j]+1,row[j-1]+(x!=y)))
        row=new
    return row[-1]

results=[]
for p in sorted((root/'review').glob('*-speech-ko.wav')):
    boundary='pdmd-local-asr-evaluation'
    chunks=[]
    for key,value in {'model':'nemotron','language':'ko'}.items():
        chunks.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode())
    chunks.append(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{p.name}"\r\nContent-Type: audio/wav\r\n\r\n'.encode()+p.read_bytes()+b'\r\n')
    chunks.append(f'--{boundary}--\r\n'.encode())
    req=urllib.request.Request('http://127.0.0.1:8693/v1/audio/transcriptions',data=b''.join(chunks),headers={'Content-Type':'multipart/form-data; boundary='+boundary})
    start=time.monotonic()
    with urllib.request.urlopen(req,timeout=180) as response: data=json.load(response)
    text=data.get('text','')
    a=re.sub(r'[^가-힣A-Za-z0-9]','',reference);b=re.sub(r'[^가-힣A-Za-z0-9]','',text)
    r=dict(case=p.stem,reference=reference,response=data,seconds=time.monotonic()-start,normalized_exact_match=a==b,normalized_character_error_rate=distance(a,b)/len(a))
    results.append(r); print(json.dumps(r,ensure_ascii=False),flush=True)
(root/'review/asr.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
