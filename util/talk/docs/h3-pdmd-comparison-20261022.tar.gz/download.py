import hashlib
import json
import os
from pathlib import Path
from huggingface_hub import hf_hub_download

rows = [
    ('Iwannapose/minimax_h3_pdmd_4nfe_comfyui', 'ae6ab62d28754b9ce052798b92d9567161568f28', 'minimax_h3_pdmd_4nfe_comfyui_v6.safetensors', 'd1d7c9f08782492ebcaa57f9f823899541ee04c48a298692a229683c4b3dd8a1'),
    ('Iwannapose/minimax_h3_pdmd_2nfe_comfyui', '3acb11d6f9bc65e68bb907a5c6b596cd719c4360', 'minimax_h3_pdmd_2nfe_comfyui.safetensors', '5feaeef13df31f98f36364a95e7ce9e8ff0afd71570d1c53d7c3be599e3a0f22'),
]
out = []
for repo, rev, name, sha in rows:
    p = Path(hf_hub_download(repo, name, revision=rev, local_dir='/trial/models', token=False))
    with p.open('rb') as f:
        actual = hashlib.file_digest(f, 'sha256').hexdigest()
        os.posix_fadvise(f.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)
    assert actual == sha, name
    out.append(dict(repo=repo, revision=rev, file=name, sha256=sha, bytes=p.stat().st_size))
    print(json.dumps(out[-1]), flush=True)
Path('/trial/models/manifest.json').write_text(json.dumps(out, indent=2))
