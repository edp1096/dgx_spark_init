"""Same production worker functions, isolated jobs, explicit PDMD arms."""
from pathlib import Path
import sys
sys.path.insert(0, '/opt/qwim-mmh3')
sys.path.insert(0, '/trial')
source = Path('/trial/source/worker.py').read_text()
prefix, suffix = source.split('\nwith torch.inference_mode():\n    for kind in', 1)
exec(compile(prefix, '/trial/source/worker.py', 'exec'), globals())
from residual_lora import ResidualLoRA

ARMS = {
    'baseline20': dict(steps=20, sampler='res_multistep', attention='sol', audio_shift=3.0, lora=None),
    'pdmd4': dict(steps=4, sampler='euler', attention='dense', audio_shift=3.0, lora='minimax_h3_pdmd_4nfe_comfyui_v6.safetensors'),
    'pdmd2': dict(steps=2, sampler='euler', attention='dense', audio_shift=6.0, lora='minimax_h3_pdmd_2nfe_comfyui.safetensors'),
}
PRODUCTION_SAMPLE = sample

def sample(kind, cond, seed, request):
    arm = ARMS[request['arm']]
    if request['arm'] == 'baseline20':
        return PRODUCTION_SAMPLE(kind, cond, seed, request)
    from comfy_extras.nodes_minimax_h3 import _empty_av_latent
    latent, _ = _empty_av_latent(request['width'], request['height'], 124)
    model = DITS[kind]
    guider = BasicGuider.execute(model, cond)[0]
    sigmas = BasicScheduler.execute(model, 'simple', arm['steps'], 1.0)[0]
    expected_t = torch.linspace(1, 0, arm['steps'] + 1)
    expected_sigmas = 12 * expected_t / (1 + 11 * expected_t)
    assert torch.allclose(sigmas, expected_sigmas, atol=1e-6), (sigmas, expected_sigmas)
    emit('pdmd_schedule', sigmas=sigmas.tolist(), audio_shift=arm['audio_shift'], sampler=arm['sampler'])
    result = SamplerCustomAdvanced.execute(RandomNoise.execute(seed)[0], guider,
                comfy.samplers.sampler_object(arm['sampler']), sigmas, latent)[0]
    samples = result['samples']
    tensors = samples.unbind() if samples.is_nested else [samples]
    assert all(torch.isfinite(t).all() for t in tensors), 'Nonfinite latent'
    return result


with torch.inference_mode():
    for kind in ('h3', 'qwim'):
        with stage('load_' + kind + '_dit'):
            model = comfy.sd.load_diffusion_model(SETTINGS['dits'][kind], model_options={}, disable_dynamic=True)
            if kind == 'qwim':
                model.model_options['transformer_options']['qwen_image21_cache'] = {'device': 'auto', 'dtype': 'int8'}
            mm.load_models_gpu([model])
            DITS[kind] = model
            del model
            cleanup()
    (ROOT / 'ready.json').write_text(json.dumps(emit('ready'), indent=2))
    active_arm = None
    adapter = None
    try:
        while not (ROOT / 'stop').exists():
            requests = sorted((ROOT / 'requests').glob('*.json'))
            if not requests:
                time.sleep(.2)
                continue
            path = requests[0]
            request = json.loads(path.read_text())
            path.rename(path.with_suffix('.running'))
            arm = ARMS[request['arm']]
            CASE = request['case']
            if request['arm'] != active_arm:
                with stage('switch_adapter'):
                    if adapter is not None:
                        report = adapter.report()
                        (ROOT / ('adapter-' + active_arm + '.json')).write_text(json.dumps(report, indent=2))
                        adapter.remove()
                        adapter = None
                    if arm['lora']:
                        adapter = ResidualLoRA(DITS['h3'], '/trial/models/' + arm['lora'])
                    sol_runtime.MODE = arm['attention']
                    DITS['h3'].model.model_sampling.set_parameters(shift=12.0, audio_shift=arm['audio_shift'])
                    active_arm = request['arm']
            # Every measured request pays its own encoder and VAE costs.
            CONDITIONING.clear()
            try:
                result = generate(request)
                result['arm'] = dict(arm)
                if adapter is not None:
                    report = adapter.report()
                    assert report['called_modules'] == 208
                    result['adapter_modules_called'] = report['called_modules']
                    (ROOT / ('adapter-' + active_arm + '.json')).write_text(json.dumps(report, indent=2))
                cleanup()
                emit('idle', seconds=result['seconds'])
                TRACKER = None
            except Exception:
                result = dict(status='error', error=traceback.format_exc(), request=request)
                print(result['error'], flush=True)
            (ROOT / 'results' / path.name).write_text(json.dumps(result, indent=2))
            if result['status'] == 'error':
                raise RuntimeError(result['error'])
    finally:
        if adapter is not None:
            adapter.remove()
