"""Extract fixed-time frames and 16 kHz WAVs for manual/ASR review."""
import json
import wave
from pathlib import Path
import av
import numpy as np
from PIL import Image, ImageDraw, ImageFont

root = Path('/trial')
out = root / 'review'
out.mkdir(exist_ok=True)
reports = []
for path in sorted((root / 'job/output').glob('*.mp4')):
    result = root / 'job/results' / (path.stem + '.json')
    if not result.exists() or json.loads(result.read_text()).get('status') != 'success':
        continue
    with av.open(str(path)) as c:
        stream = c.streams.video[0]
        fps = float(stream.average_rate)
        frames = [f.to_image() for f in c.decode(video=0)]
    audio = []
    with av.open(str(path)) as c:
        resampler = av.AudioResampler(format='s16', layout='mono', rate=16000)
        for f in c.decode(audio=0):
            audio.extend(r.to_ndarray().reshape(-1) for r in resampler.resample(f))
        audio.extend(r.to_ndarray().reshape(-1) for r in resampler.resample(None))
    pcm = np.concatenate(audio)
    with wave.open(str(out / (path.stem + '.wav')), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(16000); w.writeframes(pcm.tobytes())
    row = Image.new('RGB', (1600, 210), '#202020')
    draw = ImageDraw.Draw(row)
    draw.text((8, 5), path.stem, fill='white', font=ImageFont.load_default(size=20))
    for i, t in enumerate([0, 1.25, 2.5, 3.75, 5]):
        f = frames[min(round(t * fps), len(frames)-1)]
        row.paste(f.resize((320, 178)), (i * 320, 32))
    row.save(out / (path.stem + '.jpg'), quality=94)
    frames[0].save(out / (path.stem + '-first.png'))
    norm = pcm.astype(np.float64) / 32768
    reports.append(dict(case=path.stem, bytes=path.stat().st_size, fps=fps, frames=len(frames),
                        width=frames[0].width, height=frames[0].height,
                        video_seconds=len(frames)/fps, audio_seconds=len(pcm)/16000,
                        audio_rms=float(np.sqrt((norm**2).mean())),
                        audio_peak=float(np.abs(norm).max()),
                        audio_clipping_fraction=float((np.abs(norm)>.999).mean())))
for case in ['cat', 'speech-ko', 'i2v']:
    arms = ['baseline20','pdmd4','pdmd2'] if case != 'i2v' else ['baseline20','aux-pdmd4','aux-pdmd2']
    rows = [out / (arm+'-'+case+'.jpg') for arm in arms]
    if all(p.exists() for p in rows):
        grid = Image.new('RGB', (1600,630))
        for i,p in enumerate(rows): grid.paste(Image.open(p), (0,i*210))
        grid.save(out / (case+'-comparison.jpg'), quality=95)
(out / 'media.json').write_text(json.dumps(reports, indent=2))
print(json.dumps(reports, indent=2))
