import hashlib
import html
import json
import shutil
import subprocess
import tarfile
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

root = Path('/home/edp1096/.cache/sparktalk/experiments/h3-pdmd')
repo = Path('/home/edp1096/workspace/dgx_spark_init')
docs = repo / 'util/talk/docs'
name = 'h3-pdmd-comparison-20261022'
gallery = docs / name
(gallery/'media').mkdir(parents=True, exist_ok=True)
(gallery/'frames').mkdir(exist_ok=True)
results = []
for p in sorted((root/'job/results').glob('*.json')):
    d=json.loads(p.read_text())
    assert d['status']=='success', p.name
    results.append(d)
assert len(results)==9
for p in (root/'job/output').glob('*.mp4'):
    shutil.copy2(p,gallery/'media'/p.name)
for p in (root/'review').glob('*-comparison.jpg'):
    shutil.copy2(p,gallery/'frames'/p.name)
shutil.copy2(root/'review/cat-input.png',gallery/'frames/cat-input.png')
health=json.load(urllib.request.urlopen('http://127.0.0.1:8730/health'))
memory=json.load(urllib.request.urlopen('http://127.0.0.1:8730/v1/runtime/memory'))
initial=json.loads((root/'initial.json').read_text())
container=json.loads(subprocess.check_output(['docker','inspect','sparktalk-qwim-mmh3']))[0]
running=subprocess.check_output(['docker','ps','--format','{{.Names}}']).decode().splitlines()
assert container['Image']==initial['image_id'] and container['Mounts']==initial['mounts']
assert set(running)==set(initial['running_containers'])
assert health['status']=='ok' and not memory['busy'] and not memory['quiescing']
assert health['acceleration']['attention']=='sol'
restored=dict(health=health,memory=memory,image_same=True,mounts_same=True,running_containers_same=True)
(root/'restored.json').write_text(json.dumps(restored,indent=2))
manifest=json.loads((root/'models/manifest.json').read_text())
report={
 'status':'comparison-complete-production-restored',
 'finished_utc':datetime.now(timezone.utc).isoformat(),
 'host':'61 only; host 60 untouched',
 'recommendation':'PDMD 4 NFE is the preferred adoption candidate. 2 NFE is not recommended as the default after a Korean ASR mismatch and large audio level changes. No production promotion performed.',
 'method':{
  'samples':'One generation per arm for each of two text-to-video prompts and one image-to-video prompt; nine successful clips. Preliminary screening, not a comprehensive quality benchmark.',
  'identical':'Same prompt and seed within each case; identical base NVFP4 checkpoint, ClipProj encoder, VAEs, 864x480, 124 frames, 24fps, audio enabled; Qwen EXL3 remained online.',
  'cold_conditioning':True,
  'total_seconds':'Includes encoder, sampling, video/audio VAE decoding, cleanup and MP4 saving. Excludes model startup and adapter installation. Compilation encountered during the first generation is included.',
  'baseline':'Current production 20-step res_multistep + Sol-Attn, video/audio shifts 12/3.',
  'pdmd4':'4 Euler evaluations, dense attention, video/audio shifts 12/3, LoRA scale 1.',
  'pdmd2':'2 Euler evaluations, dense attention, video/audio shifts 12/6 per current original-author recommendation, LoRA scale 1.',
  'adapter':'BF16 low-rank residual branch added to the original NVFP4 layer output. No LoRA merging/requantization or base-weight modification. All 208 modules/624 keys validated; all 208 modules exercised.',
  'startup_retries':'Two harness setup errors were corrected: adapter key suffix assumption and admitted-image path. No failed generation entered speed/quality scores; completed baseline clips were retained.',
  'processes':'Baseline T2V, 4-NFE T2V, and remaining arms ran in three separate instances of the same image after setup fixes.'
 },
 'base':{'image_id':initial['image_id'],'checkpoint':'lilcheaty/MiniMax-H3-NVFP4','revision':'8c5abfed61e1b6a170240792b65253fba1a65b7b','filename':'minimax_h3_fl2va_pruned_nvfp4.safetensors','sha256':'72fa9269ce551fb63ff42a32d9b46d0c122e84b4b2c511e22fa698287b088f70'},
 'lora_files':manifest,
 'results':results,
 'preflight':json.loads((root/'preflight.json').read_text()),
 'adapter_validation':{},
 'media':json.loads((root/'review/media.json').read_text()),
 'korean_asr':json.loads((root/'review/asr.json').read_text()),
 'visual_review':{
  'method':'Manual inspection of frames at 0,1.25,2.5,3.75,5 seconds, not a full temporal or lip-sync metric.',
  'observations':'All variants produce recognizable scenes and coherent subject identity in sampled frames. 4-NFE T2V cat walks and turns toward the camera; the person remains visually coherent. I2V retains the cat/garden and produces rightward movement in all arms. Scenes differ between T2V arms despite equal seeds.',
  'audio_limits':'ASR checks the requested words, not subjective voice/sound quality. An ASR mismatch alone does not establish the exact pronunciation. No direct audio listening was available in this assistant environment. 2-NFE cat and I2V RMS levels are substantially higher than the baseline and 4-NFE.'
 },
 'restored':restored,
 'production_files_changed':False,
 'sources':['https://huggingface.co/pdmd2026/pdmd_2NFE_lora','https://huggingface.co/pdmd2026/pdmd_4NFE_lora','https://huggingface.co/Iwannapose/minimax_h3_pdmd_4nfe_comfyui','https://huggingface.co/Iwannapose/minimax_h3_pdmd_2nfe_comfyui','https://github.com/ZeamoxWang/pdmd','https://pdmd2026.github.io/'],
 'retained_models':'Two pinned BF16 LoRAs, 3,912,388,336 bytes, in the private experiment directory; no full base checkpoint or FP32 LoRA downloaded.',
 'raw_directory':str(root),
}
for arm in ['pdmd4','pdmd2']:
    a=json.loads((root/f'job/adapter-{arm}.json').read_text())
    report['adapter_validation'][arm]={'modules':a['modules'],'called_modules':a['called_modules'],'original_weight_objects_unchanged':a['original_weight_objects_unchanged'],'max_normalized_fp64_error':max(x['fp64_max_normalized_error'] for x in a['validation']),'allowed_max_normalized_error':.025,'scope':'Independent FP64 reassociation of low-rank residuals on two synthetic input rows and sixteen output columns per module; not a full-checkpoint equivalence proof.'}

archive=docs/(name+'.tar.gz')
paths=[root/f for f in ['run.py','trial.py','residual_lora.py','download.py','review.py','transcribe.py','package.py','cases.json','i2v-cases.json','preflight.json','restored.json','trial.log','models/manifest.json']]
paths+=list((root/'job/results').glob('*.json'))+list((root/'job').glob('adapter-*.json'))
paths+=[root/'job/events.jsonl',root/'review/media.json',root/'review/asr.json']
paths+=list((root/'results').glob('*.json'))
paths+=[root/'source'/f for f in ['worker.py','sol_runtime.py','generation_progress.py','settings.json']]
with tarfile.open(archive,'w:gz') as t:
    for p in paths:t.add(p,arcname=str(p.relative_to(root)))
report['archive']={'path':str(archive.relative_to(repo)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size}
(docs/(name+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')

lookup={r['request']['case']:r for r in results}
labels={'baseline20':'기존 20스텝','pdmd4':'PDMD 4스텝','pdmd2':'PDMD 2스텝'}
sections=[]
for case,title in [('cat','텍스트 → 영상: 고양이'),('speech-ko','텍스트 → 영상: 한국어 대사'),('i2v','이미지 → 영상: 동일 시작 이미지')]:
    cards=[]
    for arm in ['baseline20','pdmd4','pdmd2']:
        key=arm+'-'+case
        if case=='i2v' and arm!='baseline20':key='aux-'+key
        r=lookup[key]
        cards.append(f'<article><h3>{labels[arm]}</h3><p>전체 {r["seconds"]:.1f}초 · 생성 계산 {r["stages"]["sample"]:.1f}초</p><video controls muted preload="metadata" src="media/{key}.mp4"></video><button class="sound">이 영상 소리 듣기</button></article>')
    sections.append(f'<section><h2>{title}</h2><button class="play">동시에 재생</button> <button class="pause">모두 정지</button><div class="grid">'+''.join(cards)+f'</div><details><summary>같은 시간의 프레임 비교</summary><img src="frames/{case}-comparison.jpg" alt="프레임 비교"></details></section>')
doc='''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MiniMax H3 PDMD 비교</title><style>body{font:16px/1.6 system-ui;margin:24px auto;padding:0 20px;max-width:1500px;background:#10151d;color:#e9eef6}h1,h2,h3{line-height:1.25}a{color:#87bfff}section{margin:40px 0}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}article{padding:16px;background:#1b2432;border-radius:10px}video,img{width:100%}button{padding:9px 14px;margin:5px 0;background:#294b75;color:white;border:0;border-radius:6px;cursor:pointer}.note{color:#b4c1d3}details{margin-top:14px}@media(max-width:800px){.grid{grid-template-columns:1fr}}</style><h1>MiniMax H3 · PDMD 실측 비교</h1><p><strong>4스텝 우선 검토, 2스텝 기본 적용 보류.</strong> 현재 Talk는 기존 20스텝으로 복구했습니다.</p><p>61번 DGX Spark · NVFP4 + ClipProj · 864×480 · 124프레임 · 24fps · 음성 포함. 장면별 프롬프트와 시드 동일.</p><p class="note">각 조건 1회인 예비 비교입니다. 전체 시간은 인코딩·생성·VAE·저장을 포함하며, 모델 시작과 LoRA 설치는 제외합니다. 한국어 ASR: 기존/4스텝은 원문과 일치, 2스텝은 “보내세요”를 “보도세요”로 인식했습니다. ASR 결과만으로 실제 발음을 단정하지 않습니다. 직접 청취와 영상 재생으로 확인할 수 있습니다.</p>'''+''.join(sections)+'''<p>Source: <a href="../h3-pdmd-comparison-20261022.json">전체 실측 기록</a> · <a href="https://huggingface.co/pdmd2026/pdmd_2NFE_lora">PDMD 원본</a> · <a href="https://huggingface.co/Iwannapose/minimax_h3_pdmd_4nfe_comfyui">4NFE 변환본</a> · <a href="https://huggingface.co/Iwannapose/minimax_h3_pdmd_2nfe_comfyui">2NFE 변환본</a></p><script>document.querySelectorAll('section').forEach(s=>{let v=[...s.querySelectorAll('video')];s.querySelector('.play').onclick=()=>v.forEach(x=>{x.currentTime=0;x.play().catch(()=>{})});s.querySelector('.pause').onclick=()=>v.forEach(x=>x.pause());s.querySelectorAll('.sound').forEach((b,i)=>b.onclick=()=>{document.querySelectorAll('video').forEach(x=>x.muted=true);v[i].muted=false;v[i].play().catch(()=>{})})});</script></html>'''
(gallery/'index.html').write_text(doc)
print(json.dumps({'report':str(docs/(name+'.json')),'gallery':str(gallery/'index.html'),'archive':report['archive'],'rows':len(results)},indent=2))
