"""Run an isolated trial and always restore the original media container."""
import json
import subprocess
import time
import urllib.request
from pathlib import Path

ROOT = Path('/home/edp1096/.cache/sparktalk/experiments/h3-pdmd')
JOB = ROOT / 'job'
PROD = 'sparktalk-qwim-mmh3'
TRIAL = 'h3-pdmd-trial'
IMAGE = json.loads((ROOT / 'initial.json').read_text())['image_id']
prompts = [
    dict(name='cat', seed=42, prompt='integrated_multimodal_description: A single continuous medium-wide shot in a sunlit garden. One orange tabby cat walks from left to right along a low wooden fence, pauses, then turns its head toward the camera. The camera remains stationary. Natural realistic fur, coherent paws, clear motion, leafy plants behind the fence. No text or subtitles.\noverall_soundscape: Soft birds chirping and gentle rustling leaves, followed by one clear cat meow as the cat turns its head.\nnon_diegetic_music: None.'),
    dict(name='speech-ko', seed=99, prompt='integrated_multimodal_description: One continuous eye-level medium close-up of an adult Korean man in a plain blue shirt, seated in a bright quiet room. He looks directly at the camera, smiles gently and says clearly in Korean: "안녕하세요. 좋은 하루 보내세요." His lips move naturally in sync with the spoken words. He gives a small friendly wave with one hand. Realistic face, natural skin, stable camera. No subtitles, no text.\noverall_soundscape: One calm male voice saying exactly "안녕하세요. 좋은 하루 보내세요." in Korean, with faint quiet indoor room tone.\nnon_diegetic_music: None.'),
]
requests = []
for arm in ['baseline20', 'pdmd4', 'pdmd2']:
    for p in prompts:
        requests.append(dict(case=arm+'-'+p['name'], kind='h3', arm=arm,
                             prompt=p['prompt'], seed=p['seed'], width=864, height=480))
if (ROOT / 'i2v-cases.json').exists():
    requests.extend(json.loads((ROOT / 'i2v-cases.json').read_text()))
(ROOT / 'cases.json').write_text(json.dumps(requests, ensure_ascii=False, indent=2))
for folder in ['', 'requests', 'results', 'output', 'progress', 'state']:
    (JOB / folder).mkdir(parents=True, exist_ok=True)
(JOB / 'settings.json').write_bytes((ROOT / 'source/settings.json').read_bytes())
for name in ['ready.json', 'stop']:
    (JOB / name).unlink(missing_ok=True)
for path in (JOB / 'requests').glob('*.json'):
    path.unlink()

def api(path):
    return json.load(urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:8730'+path, data=b'', method='POST'), timeout=10))

def docker(*args):
    return subprocess.check_output(['docker', *args], text=True).strip()

stopped = False
log = None
try:
    print('QUIESCE', api('/v1/runtime/quiesce'), flush=True)
    docker('stop', '-t', '10', PROD)
    stopped = True
    subprocess.run(['docker', 'rm', TRIAL], capture_output=True)
    log = (ROOT / 'trial.log').open('a')
    command = ['docker', 'run', '--name', TRIAL, '--gpus', 'all', '--network', 'none', '--ipc', 'host',
               '--memory', '40g', '--memory-swap', '40g',
               '-e', 'HF_HUB_OFFLINE=1', '-e', 'HF_HOME=/hf', '-e', 'STATE_DIR=/job/state',
               '-v', '/home/edp1096/.cache/huggingface:/hf:ro', '-v', str(ROOT)+':/trial',
               '-v', str(JOB)+':/job', '--entrypoint', '/bin/bash', IMAGE, '-c',
               'python3 /opt/qwim-mmh3/prepare_models.py --release-file-cache && python3 /trial/trial.py']
    proc = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
    deadline = time.monotonic() + 600
    while not (JOB / 'ready.json').exists():
        if proc.poll() is not None:
            raise RuntimeError('Trial startup exited: '+str(proc.returncode))
        if time.monotonic() > deadline: raise TimeoutError('Trial startup')
        time.sleep(1)
    print('READY', flush=True)
    for request in requests:
        name = request['case']
        existing = JOB / 'results' / (name + '.json')
        if existing.exists() and json.loads(existing.read_text()).get('status') == 'success':
            print('REUSE_COMPLETED', name, flush=True)
            continue
        if existing.exists():
            existing.rename(ROOT / 'results' / ('setup-failure-' + existing.name))
        path = JOB / 'requests' / (name + '.json')
        temp = path.with_suffix('.tmp'); temp.write_text(json.dumps(request)); temp.replace(path)
        print('START', name, flush=True)
        deadline = time.monotonic() + 1200
        result = JOB / 'results' / path.name
        last_report = 0
        while not result.exists():
            if proc.poll() is not None: raise RuntimeError('Trial exited: '+str(proc.returncode))
            if time.monotonic() > deadline: raise TimeoutError(name)
            if time.monotonic() - last_report > 30:
                phase = (JOB / 'phase').read_text() if (JOB / 'phase').exists() else 'loading'
                print('PROGRESS', phase, flush=True); last_report = time.monotonic()
            time.sleep(1)
        data = json.loads(result.read_text())
        print('RESULT', name, data.get('status'), data.get('seconds'), flush=True)
        if data.get('status') != 'success': raise RuntimeError(data.get('error'))
    (JOB / 'stop').touch()
    proc.wait(timeout=60)
    print('DONE', flush=True)
finally:
    subprocess.run(['docker', 'stop', '-t', '10', TRIAL], capture_output=True)
    if stopped:
        print('RESTORE', docker('start', PROD), flush=True)
        deadline = time.monotonic() + 300
        while True:
            try:
                data=json.load(urllib.request.urlopen('http://127.0.0.1:8730/health', timeout=5))
                if data.get('status') == 'ok':
                    print('RESTORED_HEALTH', json.dumps(data), flush=True)
                    (ROOT/'restored.json').write_text(json.dumps(data,indent=2))
                    break
            except Exception: pass
            if time.monotonic() > deadline: raise TimeoutError('Restore health')
            time.sleep(2)
    else:
        try: api('/v1/runtime/resume')
        except Exception: pass
    if log: log.close()
