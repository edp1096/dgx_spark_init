"""Experimental H3 LoRA residuals; keep base NVFP4 weights unchanged."""
import gc
import torch
import torch.nn.functional as F
from safetensors import safe_open


class ResidualLoRA:
    def __init__(self, model, path):
        self.handles = []
        self.calls = {}
        self.weights = []
        self.validation = []
        self.bytes = 0
        with safe_open(path, framework='pt', device='cpu') as f:
            keys = set(f.keys())
            names = sorted(k[:-len('.lora_A.weight')] for k in keys if k.endswith('.lora_A.weight'))
            assert len(names) == 208, len(names)
            expected = {n + suffix for n in names for suffix in ('.lora_A.weight', '.lora_B.weight', '.alpha')}
            assert keys == expected, sorted(keys ^ expected)
            for index, name in enumerate(names):
                module = model.model.get_submodule(name)
                a = f.get_tensor(name + '.lora_A.weight').to('cuda')
                b = f.get_tensor(name + '.lora_B.weight').to('cuda')
                scale = float(f.get_tensor(name + '.alpha')) / a.shape[0]
                assert scale == 1.0
                assert a.dtype == b.dtype == torch.bfloat16
                assert tuple(module.weight.shape) == (b.shape[0], a.shape[1]), (name, module.weight.shape, a.shape, b.shape)
                assert getattr(module, 'pre_quant_scale', None) is None, name
                assert torch.isfinite(a).all() and torch.isfinite(b).all()
                self.bytes += (a.numel() + b.numel()) * a.element_size()
                # Independent association in FP64, using selected output rows.
                g = torch.Generator(device='cuda').manual_seed(1000 + index)
                x = torch.randn((2, a.shape[1]), device='cuda', dtype=torch.bfloat16, generator=g)
                cols = torch.linspace(0, b.shape[0] - 1, 16, device='cuda').long()
                actual = F.linear(F.linear(x, a), b).index_select(-1, cols).double()
                reference = x.double() @ (b.index_select(0, cols).double() @ a.double()).T
                relative = float((actual - reference).abs().max() / reference.abs().max().clamp_min(1e-10))
                assert relative < .025, (name, relative)
                self.validation.append(dict(module=name, fp64_max_normalized_error=relative))
                self.calls[name] = 0
                self.weights.append((module, module.weight))
                def hook(m, args, output, a=a, b=b, name=name):
                    self.calls[name] += 1
                    x = args[0]
                    assert x.dtype == a.dtype and x.device == a.device
                    return output + F.linear(F.linear(x, a), b)
                self.handles.append(module.register_forward_hook(hook))
        torch.cuda.synchronize()
        gc.collect()

    def report(self):
        assert all(module.weight is weight for module, weight in self.weights)
        return dict(modules=len(self.calls), called_modules=sum(n > 0 for n in self.calls.values()),
                    calls=dict(self.calls), bytes=self.bytes,
                    original_weight_objects_unchanged=True, validation=self.validation)

    def remove(self):
        for handle in self.handles:
            handle.remove()
        self.handles.clear()
        self.weights.clear()
        gc.collect()
        torch.cuda.empty_cache()
